unit Unit12;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, ComCtrls, ExtCtrls,header, StdCtrls, Menus;

type
  TForm12 = class(TForm)
    Panel1: TPanel;
    Splitter1: TSplitter;
    Panel2: TPanel;
    Edit1: TEdit;
    Label1: TLabel;
    Button1: TButton;
    Button2: TButton;
    StatusBar1: TStatusBar;
    ListBox1: TListBox;
    PopupMenu1: TPopupMenu;
    New1: TMenuItem;
    Edit2: TEdit;
    Button3: TButton;
    procedure TreeView1Expanding(Sender: TObject; Node: TTreeNode;
      var AllowExpansion: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure TreeView1MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure ListBox1DblClick(Sender: TObject);
    procedure ListBox1Click(Sender: TObject);
    procedure New1Click(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
  private
    { Private declarations }
  public
      bdata,sdata,last:tdata;
      giliran,gil:integer;
      hkey:int64;
      count:integer;
      pv:string;      
      procedure expandbook;
      procedure getdata(node:ttreenode);

    { Public declarations }
  end;

var
  Form12: TForm12;
  movelist:tstringlist;
  movel:array[0..60] of tdata;


implementation
uses movgen,makemove,tools,opening_book,notation,udata,hashing_header;
var aaa:integer;

{$R *.dfm}
procedure tform12.expandbook;
var temp:tdata;
ml:tmovelist;jml,a,n:integer;
w:integer;
m:array[1..20] of record
  moves:word;
  weight:integer;
end;
s:string;
begin
 try
  temp:=bdata;
  n:=0;
  fillchar(m,sizeof(m),0);

  if giliran=_SISIPUTIH then
  begin
    white_movgen_noncaps(bdata,ml,jml,0);
    for a:=1 to jml do
    begin
      bdata:=temp;
      aaa:=ml[a].moves;
      makewhitemove(ml[a].moves,bdata);
      if white_checked(bdata) then continue;
    end;
    bdata:=temp;
    white_movgen_caps(bdata,ml,jml);
    for a:=1 to jml do
    begin
      bdata:=temp;
      makewhitemove(ml[a].moves,bdata);
      if white_checked(bdata) then continue;
    end;

  end else
  begin
    black_movgen_noncaps(bdata,ml,jml);
    for a:=1 to jml do
    begin
      bdata:=temp;
      makeblackmove(ml[a].moves,bdata);
      if black_checked(bdata) then continue;
    end;
    bdata:=temp;
    black_movgen_caps(bdata,ml,jml);
    for a:=1 to jml do
    begin
      bdata:=temp;
      makeblackmove(ml[a].moves,bdata);
      if black_checked(bdata) then continue;
    end;

  end;
 except
 end;
end;

procedure tform12.getdata;
var ml:array[0..12] of string;
a,b:integer;
data:tdata;
moves:integer;
begin
try
 a:=1;
 initstate(data);
 while node.Text<>'root' do
 begin
   ml[a]:=node.text;
   inc(a);
   node:=node.parent;
 end;
 giliran:=_SISIPUTIH;
 for b:=a-1 downto 1 do
 begin
   moves:=notationtomove(ml[b],data,giliran);
   if giliran=_SISIPUTIH then makewhitemove(moves,data)
   else makeblackmove(moves,data);
   giliran:=3-giliran;
 end;
 bdata:=data;
except
end;

end;

procedure TForm12.TreeView1Expanding(Sender: TObject; Node: TTreeNode;
  var AllowExpansion: Boolean);
var temp:ttreenode;
s:string;
begin
try
 allowexpansion:=true;
 with (sender as ttreeview).Items do
 begin
   node.DeleteChildren;
   s:=node.Text;
   getdata(node);
//   expandbook(node);
 end;
except
end;
// form12.caption:=treeview1.Items.Item[0].Text;
end;

procedure TForm12.FormCreate(Sender: TObject);
begin
  form12.bdata:=data;
  form12.giliran:=_SISIPUTIH;
  movelist:=tstringlist.create;
  movelist.Add('root');
  initstate(sdata);
  gil:=_SISIPUTIH;
  count:=0;
  pv:='';
  fillchar(movel,sizeof(movel),0);
  movel[0]:=sdata;
end;

var anu:string;

procedure TForm12.TreeView1MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
var s:string;
node:ttreenode;
weight:integer;
begin
  try
    s:=(sender as ttreeview).GetNodeAt(x,y).Text;

    node:=(sender as ttreeview).GetNodeAt(x,y);
    getdata(node);
    try
    searchhashbook2(hashvalue(bdata,1),3-giliran,weight);
    edit1.text:=inttostr(weight);
    except
      on e:exception do
        showmessage(e.message);
    end;
    hkey:=hashvalue(bdata,1);
    anu:=s;
  except
      on e:exception do
        showmessage(e.message);

  end;
end;

procedure TForm12.Button1Click(Sender: TObject);
begin
  edithashbook(hkey,giliran,strtoint(edit1.text));
end;

procedure TForm12.Button2Click(Sender: TObject);
begin
 savebook;
end;

Function whichselected(s:tlistbox):integer;
var a:integer;
begin
  result:=-1;
  for a:=0 to s.items.Count-1 do
  begin
    if s.Selected[a] then
    begin
      result:=a;exit;
    end;
  end;

end;

function removeline(s:string):string;
var a:integer;
begin
  result:=s;
  for a:=length(s) downto 1 do
  begin
    if s[a]=' ' then
    begin
      result:=copy(s,1,a-1);exit;
    end;
  end;
end;

procedure TForm12.ListBox1DblClick(Sender: TObject);
var s:string;
moves:integer;
begin
  if whichselected(listbox1)>0 then
  begin
    s:=listbox1.Items[whichselected(listbox1)];
    listbox1.Clear;
    listbox1.items.add('...');
    if s<>'root' then
    begin
      moves:=notationtomove(s,sdata,giliran);
      if count mod 2=1 then
       pv:=pv+' '+s
      else
       pv:=pv+' '+inttostr(count div 2 + 1)+'.'+s;
      caption:=pv;
      last:=sdata;
      if giliran=_SISIPUTIH then makewhitemove(moves,sdata)
      else makeblackmove(moves,sdata);
      inc(count);
      movel[count]:=sdata;
      giliran:=3-giliran;
    end;
    bdata:=sdata;
    expandbook;
  end else
  if whichselected(listbox1)=0 then
  begin
    dec(count);
    bdata:=movel[count];
    sdata:=movel[count];


    listbox1.Clear;
    listbox1.Items.add('...');
    giliran:=3-giliran;
    pv:=removeline(pv);
    caption:=pv;
    expandbook;
  end;
end;

procedure TForm12.ListBox1Click(Sender: TObject);
var weight,moves:integer;
s:string;
var t:tdata;
begin
  if whichselected(listbox1)>0 then
  begin
    s:=listbox1.Items[whichselected(listbox1)];
    if s<>'root' then
    begin
      t:=movel[count];
      moves:=notationtomove(s,t,giliran);
      if giliran=_SISIPUTIH then makewhitemove(moves,t)
      else makeblackmove(moves,t);
      hkey:=hashvalue(t,1);

    end;
  end;
end;

procedure TForm12.New1Click(Sender: TObject);
var weight,moves:integer;
s:string;
var t:tdata;

begin
      t:=movel[count];
      s:=edit2.text;
      moves:=notationtomove(s,t,giliran);
      if giliran=_SISIPUTIH then makewhitemove(moves,t)
      else makeblackmove(moves,t);
      hkey:=hashvalue(t,1);

  {    if searchhashbook2(hashvalue(t,1),giliran,weight) then
        edit1.text:=inttostr(weight);}


end;

procedure TForm12.FormDestroy(Sender: TObject);
begin
  movelist.free;
end;

end.
