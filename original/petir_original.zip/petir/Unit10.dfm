object Form10: TForm10
  Left = 335
  Top = 157
  Width = 390
  Height = 301
  Caption = 'Custom Time'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 112
    Top = 37
    Width = 73
    Height = 13
    Caption = 'minutes / game'
  end
  object Label2: TLabel
    Left = 112
    Top = 86
    Width = 77
    Height = 13
    Caption = 'seconds / move'
  end
  object Label3: TLabel
    Left = 111
    Top = 135
    Width = 42
    Height = 13
    Caption = 'moves in'
  end
  object Label4: TLabel
    Left = 237
    Top = 135
    Width = 36
    Height = 13
    Caption = 'minutes'
  end
  object Label5: TLabel
    Left = 112
    Top = 187
    Width = 95
    Height = 13
    Caption = 'minutes / game plus'
  end
  object Label6: TLabel
    Left = 285
    Top = 187
    Width = 77
    Height = 13
    Caption = 'seconds / move'
  end
  object RadioButton1: TRadioButton
    Left = 21
    Top = 13
    Width = 113
    Height = 17
    Caption = 'Minutes / game'
    Checked = True
    TabOrder = 0
    TabStop = True
  end
  object Edit1: TEdit
    Left = 39
    Top = 35
    Width = 65
    Height = 21
    TabOrder = 1
    OnClick = Edit1Click
  end
  object RadioButton2: TRadioButton
    Left = 21
    Top = 63
    Width = 113
    Height = 17
    Caption = 'Seconds / move'
    TabOrder = 2
    OnClick = RadioButton2Click
  end
  object Edit2: TEdit
    Left = 39
    Top = 84
    Width = 65
    Height = 21
    TabOrder = 3
    OnClick = Edit2Click
  end
  object RadioButton3: TRadioButton
    Left = 20
    Top = 114
    Width = 113
    Height = 17
    Caption = 'Moves / minutes'
    TabOrder = 4
    OnClick = RadioButton3Click
  end
  object Edit3: TEdit
    Left = 38
    Top = 133
    Width = 65
    Height = 21
    TabOrder = 5
    OnClick = Edit3Click
  end
  object Edit4: TEdit
    Left = 164
    Top = 133
    Width = 65
    Height = 21
    TabOrder = 6
    OnClick = Edit3Click
  end
  object RadioButton4: TRadioButton
    Left = 21
    Top = 165
    Width = 193
    Height = 17
    Caption = 'Minutes / game with increment'
    TabOrder = 7
    OnClick = RadioButton4Click
  end
  object Edit5: TEdit
    Left = 39
    Top = 185
    Width = 65
    Height = 21
    TabOrder = 8
    OnClick = Edit5Click
  end
  object Edit6: TEdit
    Left = 212
    Top = 185
    Width = 65
    Height = 21
    TabOrder = 9
    OnClick = Edit5Click
  end
  object Button1: TButton
    Left = 93
    Top = 225
    Width = 75
    Height = 25
    Caption = 'OK'
    Default = True
    ModalResult = 1
    TabOrder = 10
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 213
    Top = 225
    Width = 75
    Height = 25
    Cancel = True
    Caption = 'Cancel'
    ModalResult = 2
    TabOrder = 11
  end
end
