unit Unitnewgame;

interface

uses
  Windows, Messages, SysUtils,  Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls,header;

type
  TFormNewGame = class(TForm)
    RadioGroup1: TRadioGroup;
    RadioGroup2: TRadioGroup;
    Button1: TButton;
    Button2: TButton;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FormNewGame: TFormNewGame;

implementation
  uses unit1,udata;

{$R *.dfm}

procedure TFormNewGame.Button1Click(Sender: TObject);
begin
  if (radiogroup1.itemindex=0) and (radiogroup2.itemindex=0) then players:=_TWOPLAYERS else
  if (radiogroup1.itemindex=0) and (radiogroup2.itemindex=1) then players:=_PLAYERVSCOMP else
  if (radiogroup1.itemindex=1) and (radiogroup2.itemindex=0) then players:=_COMPVSPLAYER else
  if (radiogroup1.itemindex=1) and (radiogroup2.itemindex=1) then players:=_COMPVSCOMP;
end;

end.
