unit Unit7;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Grids, Menus;

type
  TFormIterative = class(TForm)
    StringGrid1: TStringGrid;
    PopupMenu1: TPopupMenu;
    Savetofile1: TMenuItem;
    SaveDialog1: TSaveDialog;
    procedure FormCreate(Sender: TObject);
    procedure Savetofile1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FormIterative: TFormIterative;

implementation

{$R *.dfm}

procedure TFormIterative.FormCreate(Sender: TObject);
begin
  stringgrid1.Cells[0,0]:='D';
  stringgrid1.Cells[1,0]:='Time';
  stringgrid1.Cells[2,0]:='S';
  stringgrid1.Cells[3,0]:='Principal Variation';
end;

procedure TFormIterative.Savetofile1Click(Sender: TObject);
var a,b:integer;
f:textfile;
begin
 if savedialog1.Execute then
 begin
     assignfile(f,savedialog1.filename);
     rewrite(f);
     for a:=0 to stringgrid1.RowCount-1 do
     begin
       for b:=0 to stringgrid1.ColCount-1 do
       begin
         write(f,' ');
         write(f,stringgrid1.cells[b,a]);
       end;
       writeln(f);
     end;
     closefile(f);
 end;
end;

end.
