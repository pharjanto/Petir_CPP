object Form12: TForm12
  Left = 192
  Top = 110
  Width = 746
  Height = 480
  Caption = 'Opening Book Editor'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Splitter1: TSplitter
    Left = 97
    Top = 0
    Height = 441
  end
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 97
    Height = 441
    Align = alLeft
    TabOrder = 0
    object ListBox1: TListBox
      Left = 32
      Top = 16
      Width = 49
      Height = 369
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ItemHeight = 20
      Items.Strings = (
        '...'
        'root')
      ParentFont = False
      PopupMenu = PopupMenu1
      TabOrder = 0
      OnClick = ListBox1Click
      OnDblClick = ListBox1DblClick
    end
  end
  object Panel2: TPanel
    Left = 100
    Top = 0
    Width = 630
    Height = 441
    Align = alClient
    TabOrder = 1
    object Label1: TLabel
      Left = 24
      Top = 72
      Width = 40
      Height = 13
      Caption = 'Weight :'
    end
    object Edit1: TEdit
      Left = 24
      Top = 96
      Width = 121
      Height = 21
      TabOrder = 0
      Text = '0'
    end
    object Button1: TButton
      Left = 24
      Top = 136
      Width = 75
      Height = 25
      Caption = 'Edit'
      TabOrder = 1
      OnClick = Button1Click
    end
    object Button2: TButton
      Left = 24
      Top = 176
      Width = 75
      Height = 25
      Caption = 'Save Book'
      TabOrder = 2
      OnClick = Button2Click
    end
    object StatusBar1: TStatusBar
      Left = 1
      Top = 421
      Width = 628
      Height = 19
      Panels = <
        item
          Width = 50
        end>
    end
    object Edit2: TEdit
      Left = 8
      Top = 224
      Width = 121
      Height = 21
      TabOrder = 4
    end
    object Button3: TButton
      Left = 40
      Top = 272
      Width = 75
      Height = 25
      Caption = 'New'
      TabOrder = 5
      OnClick = New1Click
    end
  end
  object PopupMenu1: TPopupMenu
    Left = 472
    Top = 128
    object New1: TMenuItem
      Caption = 'New'
      OnClick = New1Click
    end
  end
end
