object FormAlgoritma: TFormAlgoritma
  Left = 229
  Top = 131
  Width = 535
  Height = 507
  BorderIcons = []
  Caption = 'Algorithms'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label5: TLabel
    Left = 290
    Top = 321
    Width = 68
    Height = 13
    Caption = 'Thread Priority'
    Color = clSilver
    ParentColor = False
  end
  object Label6: TLabel
    Left = 290
    Top = 353
    Width = 78
    Height = 13
    Caption = 'Hash Table Size'
    Color = clSilver
    ParentColor = False
  end
  object Label12: TLabel
    Left = 290
    Top = 385
    Width = 80
    Height = 13
    Caption = 'Algoritma Search'
    Color = clSilver
    ParentColor = False
  end
  object GroupBox1: TGroupBox
    Left = 18
    Top = 20
    Width = 255
    Height = 163
    Caption = 'Pruning'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlack
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    object Label1: TLabel
      Left = 138
      Top = 24
      Width = 38
      Height = 13
      Caption = 'Margin :'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object Label2: TLabel
      Left = 138
      Top = 58
      Width = 38
      Height = 13
      Caption = 'Margin :'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object Label4: TLabel
      Left = 138
      Top = 92
      Width = 38
      Height = 13
      Caption = 'Margin :'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object CheckBox1: TCheckBox
      Tag = 1
      Left = 16
      Top = 24
      Width = 97
      Height = 17
      Caption = 'Lazy Eval'
      Checked = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      State = cbChecked
      TabOrder = 0
      OnClick = CheckBox1Click
    end
    object CheckBox2: TCheckBox
      Tag = 2
      Left = 16
      Top = 58
      Width = 97
      Height = 17
      Caption = 'Futility Pruning'
      Checked = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      State = cbChecked
      TabOrder = 1
      OnClick = CheckBox1Click
    end
    object CheckBox4: TCheckBox
      Tag = 4
      Left = 16
      Top = 92
      Width = 121
      Height = 17
      Caption = 'Quiescene Pruning'
      Checked = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      State = cbChecked
      TabOrder = 2
      OnClick = CheckBox1Click
    end
    object CheckBox5: TCheckBox
      Left = 16
      Top = 126
      Width = 121
      Height = 17
      Caption = 'Null Move Pruning'
      Checked = True
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      State = cbChecked
      TabOrder = 3
      OnClick = CheckBox1Click
    end
    object Edit1: TEdit
      Left = 186
      Top = 23
      Width = 41
      Height = 21
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      TabOrder = 4
      Text = '250'
    end
    object Edit2: TEdit
      Left = 186
      Top = 56
      Width = 41
      Height = 21
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      TabOrder = 5
      Text = '250'
    end
    object Edit3: TEdit
      Left = 186
      Top = 87
      Width = 41
      Height = 21
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clBlack
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
      TabOrder = 6
      Text = '250'
    end
  end
  object Button1: TButton
    Tag = 1
    Left = 172
    Top = 427
    Width = 75
    Height = 25
    Caption = 'OK'
    Default = True
    ModalResult = 1
    TabOrder = 1
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 268
    Top = 427
    Width = 75
    Height = 25
    Cancel = True
    Caption = 'Cancel'
    ModalResult = 2
    TabOrder = 2
  end
  object ComboBox1: TComboBox
    Left = 386
    Top = 319
    Width = 121
    Height = 21
    ItemHeight = 13
    TabOrder = 3
    Text = 'ABOVE_NORMAL'
    Items.Strings = (
      'LOWEST'
      'BELOW_NORMAL'
      'NORMAL'
      'ABOVE_NORMAL'
      'HIGHEST')
  end
  object ComboBox2: TComboBox
    Left = 386
    Top = 350
    Width = 121
    Height = 21
    ItemHeight = 13
    TabOrder = 4
    Text = '32 MB'
    Items.Strings = (
      '8 MB'
      '16 MB'
      '32 MB'
      '64 MB'
      '128 MB'
      '256 MB')
  end
  object GroupBox2: TGroupBox
    Left = 16
    Top = 196
    Width = 257
    Height = 215
    Caption = 'Fractional Extension'
    TabOrder = 5
    object Label3: TLabel
      Left = 91
      Top = 21
      Width = 80
      Height = 13
      Caption = 'Check Extension'
      Color = clSilver
      ParentColor = False
    end
    object Label7: TLabel
      Left = 63
      Top = 53
      Width = 108
      Height = 13
      Caption = 'Single Reply Extension'
      Color = clSilver
      ParentColor = False
    end
    object Label8: TLabel
      Left = 64
      Top = 86
      Width = 107
      Height = 13
      Caption = 'Mate Threat Extension'
      Color = clSilver
      ParentColor = False
    end
    object Label9: TLabel
      Left = 38
      Top = 119
      Width = 133
      Height = 13
      Caption = 'Pushed Pawn Ext. Midgame'
      Color = clSilver
      ParentColor = False
    end
    object Label10: TLabel
      Left = 36
      Top = 152
      Width = 135
      Height = 13
      Caption = 'Pushed Pawn Ext. Endgame'
      Color = clSilver
      ParentColor = False
    end
    object Label11: TLabel
      Left = 12
      Top = 185
      Width = 159
      Height = 13
      Caption = 'Pushed Pawn Ext. Late Endgame'
      Color = clSilver
      ParentColor = False
    end
    object Edit4: TEdit
      Left = 188
      Top = 17
      Width = 33
      Height = 21
      ReadOnly = True
      TabOrder = 0
      Text = '0'
    end
    object UpDown1: TUpDown
      Tag = 4
      Left = 221
      Top = 18
      Width = 17
      Height = 21
      Min = 0
      Position = 0
      TabOrder = 1
      Thousands = False
      Wrap = False
      OnChangingEx = UpDown1ChangingEx
    end
    object Edit5: TEdit
      Left = 188
      Top = 49
      Width = 33
      Height = 21
      ReadOnly = True
      TabOrder = 2
      Text = '0'
    end
    object UpDown2: TUpDown
      Tag = 5
      Left = 221
      Top = 50
      Width = 17
      Height = 22
      Min = 0
      Position = 0
      TabOrder = 3
      Wrap = False
      OnChangingEx = UpDown1ChangingEx
    end
    object Edit6: TEdit
      Left = 188
      Top = 81
      Width = 32
      Height = 21
      ReadOnly = True
      TabOrder = 4
      Text = '0'
    end
    object UpDown3: TUpDown
      Tag = 6
      Left = 220
      Top = 82
      Width = 17
      Height = 22
      Min = 0
      Position = 0
      TabOrder = 5
      Wrap = False
      OnChangingEx = UpDown1ChangingEx
    end
    object Edit7: TEdit
      Left = 187
      Top = 114
      Width = 32
      Height = 21
      ReadOnly = True
      TabOrder = 6
      Text = '0'
    end
    object UpDown4: TUpDown
      Tag = 7
      Left = 219
      Top = 115
      Width = 17
      Height = 22
      Min = 0
      Position = 0
      TabOrder = 7
      Wrap = False
      OnChangingEx = UpDown1ChangingEx
    end
    object Edit8: TEdit
      Left = 186
      Top = 147
      Width = 32
      Height = 21
      ReadOnly = True
      TabOrder = 8
      Text = '0'
    end
    object UpDown5: TUpDown
      Tag = 8
      Left = 218
      Top = 148
      Width = 17
      Height = 22
      Min = 0
      Position = 0
      TabOrder = 9
      Wrap = False
      OnChangingEx = UpDown1ChangingEx
    end
    object Edit9: TEdit
      Left = 185
      Top = 181
      Width = 32
      Height = 21
      ReadOnly = True
      TabOrder = 10
      Text = '0'
    end
    object UpDown6: TUpDown
      Tag = 9
      Left = 217
      Top = 182
      Width = 17
      Height = 22
      Min = 0
      Position = 0
      TabOrder = 11
      Wrap = False
      OnChangingEx = UpDown1ChangingEx
    end
  end
  object RadioGroup1: TRadioGroup
    Left = 290
    Top = 196
    Width = 142
    Height = 105
    Caption = 'Pondering'
    ItemIndex = 0
    Items.Strings = (
      'Off'
      'Fill Hash Table'
      'Think Next Move')
    TabOrder = 6
  end
  object ComboBox3: TComboBox
    Left = 386
    Top = 382
    Width = 121
    Height = 21
    ItemHeight = 13
    TabOrder = 7
    Text = 'Negascout'
    Items.Strings = (
      'Negascout'
      'MTD(f)')
  end
end
