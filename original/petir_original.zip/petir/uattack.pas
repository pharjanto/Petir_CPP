unit uattack;

interface

implementation

end.
