unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls, Spin;

type
  TFormAlgoritma = class(TForm)
    GroupBox1: TGroupBox;
    CheckBox1: TCheckBox;
    Button1: TButton;
    Button2: TButton;
    CheckBox2: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    Edit1: TEdit;
    Label1: TLabel;
    Edit2: TEdit;
    Label2: TLabel;
    Edit3: TEdit;
    Label4: TLabel;
    ComboBox1: TComboBox;
    Label5: TLabel;
    Label6: TLabel;
    ComboBox2: TComboBox;
    GroupBox2: TGroupBox;
    Label3: TLabel;
    Edit4: TEdit;
    UpDown1: TUpDown;
    Label7: TLabel;
    Edit5: TEdit;
    UpDown2: TUpDown;
    Label8: TLabel;
    Edit6: TEdit;
    UpDown3: TUpDown;
    Label9: TLabel;
    Edit7: TEdit;
    UpDown4: TUpDown;
    Label10: TLabel;
    Edit8: TEdit;
    UpDown5: TUpDown;
    Label11: TLabel;
    Edit9: TEdit;
    UpDown6: TUpDown;
    RadioGroup1: TRadioGroup;
    Label12: TLabel;
    ComboBox3: TComboBox;
    procedure Button1Click(Sender: TObject);
    procedure CheckBox1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure UpDown1ChangingEx(Sender: TObject; var AllowChange: Boolean;
      NewValue: Smallint; Direction: TUpDownDirection);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FormAlgoritma: TFormAlgoritma;

implementation
  uses header;

{$R *.dfm}

procedure TFormAlgoritma.Button1Click(Sender: TObject);
begin
  use_mtdf:=combobox3.ItemIndex=1;

  if checkbox1.checked then
  begin
    lazyOK:=true;
    lazy_margin1:=strtoint(edit1.Text);
  end else lazyOK:=false;
  if checkbox2.checked then
  begin
    futpruningOK:=true;
    futil_margin:=strtoint(edit2.Text);
  end else futpruningOK:=false;
  if checkbox4.checked then
  begin
    qpruningOK:=true;
    q_margin:=strtoint(edit3.Text);
  end else qpruningOK:=false;

  if checkbox5.checked then
  begin
    NullOK:=true;
  end else nullOK:=false;

  case combobox1.ItemIndex of
    1 : thread_priority:=THREAD_PRIORITY_BELOW_NORMAL;
    3 : thread_priority:=THREAD_PRIORITY_ABOVE_NORMAL;
    4 : thread_priority:=THREAD_PRIORITY_HIGHEST;
    0 : thread_priority:=THREAD_PRIORITY_LOWEST;
    2 : thread_priority:=THREAD_PRIORITY_NORMAL;
  end;

  case combobox2.ItemIndex of
   0 : maxhash:=262144*1 ;
   1 : maxhash:=262144*2 ;
   2 : maxhash:=262144*4 ;
   3 : maxhash:=262144*8 ;
   4 : maxhash:=262144*16 ;
  end;

  SKAK_EXTENSION:=round(strtofloat(edit4.text)*fractional_ply);
  SINGLE_REPLY_EXTENSION:=round(strtofloat(edit5.text)*fractional_ply);
  MATE_THREAT_EXTENSION:=round(strtofloat(edit6.text)*fractional_ply);
  PUSHED_PAWN_EXTENSION_MIDGAME:=round(strtofloat(edit7.text)*fractional_ply);
  PUSHED_PAWN_EXTENSION_ENDGAME:=round(strtofloat(edit8.text)*fractional_ply);
  PUSHED_PAWN_EXTENSION_LATE_ENDGAME:=round(strtofloat(edit9.text)*fractional_ply);
end;

procedure TFormAlgoritma.CheckBox1Click(Sender: TObject);
begin
  if (sender as tcheckbox).tag>0 then
   (findcomponent('edit'+inttostr((sender as tcheckbox).tag)) as tedit).enabled:=(sender as tcheckbox).Checked;
end;

procedure TFormAlgoritma.FormCreate(Sender: TObject);
begin
 edit1.text:=inttostr(lazy_margin1);
 edit2.text:=inttostr(futil_margin);
 edit3.text:=inttostr(q_margin);
 if use_mtdf then combobox1.ItemIndex:=1 else combobox1.ItemIndex:=0;
 checkbox1.checked:=lazyok;
 checkbox2.Checked:=futpruningok;

 checkbox4.Checked:=qpruningok;
 checkbox5.Checked:=nullok;

 case thread_priority of
  THREAD_PRIORITY_BELOW_NORMAL : combobox1.ItemIndex:=1;
  THREAD_PRIORITY_ABOVE_NORMAL : combobox1.ItemIndex:=3;
  THREAD_PRIORITY_HIGHEST : combobox1.ItemIndex:=4;
  THREAD_PRIORITY_LOWEST : combobox1.ItemIndex:=0;
  THREAD_PRIORITY_NORMAL : combobox1.ItemIndex:=2;
 end;

 case maxhash of
   262144*1 : combobox2.ItemIndex:=0;
   262144*2 : combobox2.ItemIndex:=1;
   262144*4 : combobox2.ItemIndex:=2;
   262144*8 : combobox2.ItemIndex:=3;
   262144*16 : combobox2.ItemIndex:=4;
 end;
 updown1.Position:=round((SKAK_EXTENSION/Fractional_ply)*4);
 edit4.text:=floattostr(skak_extension/fractional_ply);
 updown2.Position:=round((SINGLE_REPLY_EXTENSION/Fractional_ply)*4);
 edit5.text:=floattostr(SINGLE_REPLY_EXTENSION/fractional_ply);
 updown3.Position:=round((MATE_THREAT_EXTENSION/Fractional_ply)*4);
 edit6.text:=floattostr(MATE_THREAT_EXTENSION/fractional_ply);
 updown4.Position:=round((PUSHED_PAWN_EXTENSION_MIDGAME/Fractional_ply)*4);
 edit7.text:=floattostr(PUSHED_PAWN_EXTENSION_MIDGAME/fractional_ply);
 updown5.Position:=round((PUSHED_PAWN_EXTENSION_ENDGAME/Fractional_ply)*4);
 edit8.text:=floattostr(PUSHED_PAWN_EXTENSION_ENDGAME/fractional_ply);
 updown6.Position:=round((PUSHED_PAWN_EXTENSION_LATE_ENDGAME/Fractional_ply)*4);
 edit9.text:=floattostr(PUSHED_PAWN_EXTENSION_LATE_ENDGAME/fractional_ply);

end;

procedure TFormAlgoritma.UpDown1ChangingEx(Sender: TObject;
  var AllowChange: Boolean; NewValue: Smallint;
  Direction: TUpDownDirection);
begin
 if (newvalue<0)  then allowchange:=false else 
 (findcomponent('edit'+inttostr((sender as tupdown).tag)) as tedit).text:=floattostr(newvalue / 4);
end;

end.
