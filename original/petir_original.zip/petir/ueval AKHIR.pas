//unit ueval berisi seluruh evaluasi papan
unit ueval;

interface
uses header,bitboard_mask;

function eval(data:tdata;giliran,alpha,beta:integer):integer;
function materialvalue(ms:integer):integer;
function isdraw(data:tdata;giliran:integer):boolean;

implementation
uses evalmask;
var anu5:integer;

const

nilai_kuda_outpost_w:array[0..63] of byte=
(
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  8,  8,  0,0 ,0,
 0 ,0 , 12, 16, 16, 12,0 ,0,
 0 ,8 , 12, 24, 24, 12,8 ,0,
 0 ,0 ,  6, 12, 12,  6,0 ,0,
 0 ,0 ,  0,  0,  0, 0, 0 ,0
);

nilai_kuda_outpost_b:array[0..63] of byte=
(
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  6, 12, 12,  6,0 ,0,
 0 ,8 , 12, 24, 24, 12,8 ,0,
 0 ,0 , 12, 16, 16, 12,0 ,0,
 0 ,0 ,  0,  8,  8,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0, 0, 0 ,0
);




nilai_gajah_outpost_w:array[0..63] of byte=
(
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  6,  6,  0,0 ,0,
 0 ,0 ,  0,  8,  8,  0,0 ,0,
 0 ,0 ,  4,  4,  4,  4,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0, 0, 0 ,0
);

nilai_gajah_outpost_b:array[0..63] of byte=
(
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  4,  4,  4,  4,0 ,0,
 0 ,0 ,  0,  8,  8,  0,0 ,0,
 0 ,0 ,  0,  6,  6,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0,  0,0 ,0,
 0 ,0 ,  0,  0,  0, 0, 0 ,0
);


nilai_pos_kuda_w:array[0..63] of shortint=
(

 -16,  -8, -8, -8, -8, -10, -8, -16,
 -8,  -4,  0,  0,  0,  0, -4, -8,
 -8,   2,  2,  3,  3,  2,  2, -8,
 -5,   2,  5,  7,  7,  5,  2, -5,
 -5,   2,  8, 12, 12,  8,  2, -5,
 -5,   2,  8, 15, 15,  8,  2, -5,
 -24,-12,  2,  2,  2,  2,-12, -24,
 -32,-16, -8, -8, -8, -8,-16, -32
);
nilai_pos_kuda_b:array[0..63] of shortint=
(
 -32,-16, -8, -8, -8, -8,-16,-32,
 -24,-12,  2,  2,  2,  2,-12,-24,
 -4 ,  2,  8, 15, 15,  8,  2, -4,
 -4 ,  2,  8, 12, 12,  8,  2, -4,
 -4 ,  2,  5,  7,  7,  5,  2, -4,
 -8 ,  2,  2,  3,  3,  2,  2, -8,
 -8 , -4,  0,  0,  0,  0, -4, -8,
 -16 , -8, -8, -8, -8, -10, -8, -16
 );

//nilai piece square untuk gajah putih
//perhatikan ada ketidak-simetrian pada petak c1 dan f1
//c1 bernilai -8 sedangkan f1 bernilai -10
//hal ini dilakukan agar mendorong gajah raja keluar lebih cepat agar raja bisa lebih
//cepat promosi
 nilai_pos_gajah_w:array[0..63] of shortint=
(
-24,-16,-8,-8,-8,-10,-16,-24,
-4,  4,  0,  0,  0,  0,  4,-4,
-4,  3, 2, 2, 2, 2,  3, -4,
-4,  2, 4, 4, 4, 4,  2, -4,
-4,  2, 6, 6, 6, 6,  2, -4,
-2,  2, 6, 6, 6, 6,  2, -2,
-16,  2, 4, 4, 4, 4,  2,-16,
-16,-16,  0,  0,  0,  0,-16,-16
);

 nilai_pos_gajah_b:array[0..63] of shortint=
(

-16,-16,  0,  0,  0,  0,-16,-16,
-16,  2, 4, 4, 4, 4,  2,-16,
-2,  2, 6, 6, 6, 6,  2, -2,
-4,  2, 6, 6, 6, 6,  2, -4,
-4,  2, 4, 4, 4, 4,  2, -4,
-4,  3, 2, 2, 2, 2,  3, -4,
-4,  4,  0,  0,  0,  0,  4,-4,
-24,-16,-8,-8,-8,-10,-16,-24
);

nilai_pos_benteng:array[0..63] of shortint=
(
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0,
 0 , 0 ,2,5,5,2, 0 , 0
);

 nilai_pos_raja_w:array[0..63] of byte=
(
1 ,0 ,1 ,12,12,1 ,0 ,1 ,
2 ,3 ,8 ,15,15,8 ,3 ,2 ,
12,12,15,22,22,15,12,12,
18,18,22,25,25,22,18,18,
25,25,27,30,30,27,25,25,
30,30,33,35,35,33,30,30,
45,45,48,50,50,48,45,45,
60,60,65,70,70,65,60,60

);

 nilai_pos_raja_b:array[0..63] of byte=
(
60,60,65,70,70,65,60,60,
45,45,48,50,50,48,45,45,
30,30,33,35,35,33,30,30,
25,25,27,30,30,27,25,25,
18,18,22,25,25,22,18,18,
12,12,15,22,22,15,12,12,
2 ,3 ,8 ,15,15,8 ,3 ,2 ,
1 ,0 ,1 ,12,12,1 ,0 ,1

);

nilai_pos_pion_w:array[0..63] of shortint=
(
0 , 0  ,0  ,0  ,0  ,0  ,0  ,0,
0 , 0  ,-1 ,-9,-9,-1 ,0  ,0,
0 , 1  ,2  ,-2 ,-2 ,2  ,1  ,0,
1 , 3  ,5  ,7  ,7  ,5  ,3  ,1,
3 , 5  ,6  ,9 ,9 ,6  ,5  ,3,
6 , 8  ,10 ,12 ,12 ,10 ,8  ,6,
8 , 10 ,12 ,15 ,15 ,12 ,10 ,8,
0 , 0  ,0  ,0  ,0  ,0  ,0  ,0
);


nilai_pos_pion_b:array[0..63] of shortint=
(
0 , 0  ,0  ,0  ,0  ,0  ,0  ,0,
8 , 10 ,12 ,15 ,15 ,12 ,10 ,8,
6 , 8  ,10 ,12 ,12 ,10 ,8  ,6,
3 , 5  ,6  ,9 ,9 ,6  ,5  ,3,
1 , 3  ,5  ,7  ,7  ,5  ,3  ,1,
0 , 1  ,2  ,-2 ,-2 ,2  ,1  ,0,
0 , 0  ,-1 ,-9,-9,-1 ,0  ,0,
0 , 0  ,0  ,0  ,0  ,0  ,0  ,0
);

nilai_pos_raja_endk_w:array[0..63] of shortint=
(
-35, -25,-20,-20,-15,-15,-10,-10,
-30, -15,-15,-10,-10,- 5,- 5,- 5,
-30, -15,-10,- 5,10 ,10 ,10 , 0 ,
-30, -15,-10,- 5,20 ,20 ,20 , 0 ,
-30, -15,-10,- 5,20 ,20 ,20 , 0 ,
-30, -15,-10,- 5,20 ,20 ,20 , 0 ,
-30, -15,-15,-10,0  ,0  ,0  ,- 5,
-35, -25,-20,-15,-10,- 5,- 5,-10
);

nilai_pos_raja_endq_w:array[0..63] of shortint=
(
-10,-10,-15,-15,-20,-20,-25,-35,
- 5,- 5,- 5,-10,-10,-15,-15,-30,
0  ,10 ,10 ,10 ,- 5,-10,-15,-30,
0  ,20 ,20 ,20 ,- 5,-10,-15,-30,
0  ,20 ,20 ,20 ,- 5,-10,-15,-30,
0  ,20 ,20 ,20 ,- 5,-10,-15,-30,
- 5,0  ,0  ,0  ,-10,-15,-15,-30,
-10,- 5,- 5,-10,-15,-20,-25,-35
);

nilai_pos_raja_endq_b:array[0..63] of shortint=
(
-10,- 5,- 5,-10,-15,-20,-25,-35,
- 5,0  ,0,0,-10,-15,-15,-30,
0  ,20 ,20 ,20 ,- 5,-10,-15,-30,
0  ,20 ,20 ,20 ,- 5,-10,-15,-30,
0  ,20 ,20 ,20 ,- 5,-10,-15,-30,
0  ,10 ,10 ,10 ,- 5,-10,-15,-30,
- 5,- 5,- 5,-10,-10,-15,-15,-30,
-10,-10,-15,-15,-20,-20,-25,-35
);


nilai_pos_raja_endk_b:array[0..63] of shortint=
(
-35, -25,-20,-15,-10,- 5,-10,-10,
-30, -15,-15,-10,0  ,0  ,0  ,- 5,
-30, -15,-10,- 5,20 ,20 ,20 , 0 ,
-30, -15,-10,- 5,20 ,20 ,20 , 0 ,
-30, -15,-10,- 5,20 ,20 ,20 , 0 ,
-30, -15,-10,- 5,10 ,10 ,10 , 0 ,
-30, -15,-15,-10,-10,- 5,- 5,- 5,
-35, -25,-20,-20,-15,-15,-10,-10
);

nilai_pos_raja_endn_w:array[0..63] of shortint=
(
  -25, -20, -15, -20, -20, -30, -20, -25,
  -15, -10, - 5,   0,   0, -10, -10, -15,
  -15, - 5,   0,   5,   5,   0, - 5, -15,
  -15, - 5,  10,  20,  20,  10, - 5, -15,
  -15, - 5,  20,  30,  30,  20, - 5, -15,
  -15, - 5,  20,  30,  30,  20, - 5, -15,
  -15, -15,   0,   0,   0,   0, -15, -15,
  -25, -15, -15, -15, -15, -15, -15, -25
);
nilai_pos_raja_endn_b:array[0..63] of shortint=
(
  -25, -15, -15, -15, -15, -15, -15, -25,
  -15, -15,   0,   0,   0,   0, -15, -15,
  -15, - 5,  20,  30,  30,  20, - 5, -15,
  -15, - 5,  20,  30,  30,  20, - 5, -15,
  -15, - 5,  10,  20,  20,  10, - 5, -15,
  -15, - 5,   0,   5,   5,   0, - 5, -15,
  -15, -10, - 5,   0,   0, - 5, -10, -15,
  -25, -20, -15, -10, -10, -15, -20, -25);

nilai_pos_mentri_w:array[0..63] of shortint = (
  -10,  -8,  0,  0,  0, 0,  -8, -10,
  -10,   2,  4,  4,  4, 4,   2, -10,
  - 5,   2,  3,  6,  6, 3,   2, -5 ,
  - 3,   2,  6,  8,  8,  6,  2, -3 ,
    0,   2,  6,  8,  8,  6,  2,   0,
    0,   2,  4,  6,  6,  4,  2,   0,
    0,   0,  4,  5,  5,  4,  0,   0,
    0,   0,  0,  0,  0,  0,  0, 0
);

nilai_pos_mentri_b:array[0..63] of shortint = (
    0,   0,  0,  0,  0,  0,  0, 0,
    0,   0,  4,  5,  5,  4,  0,   0,
    0,   2,  4,  6,  6,  4,  2,   0,
    0,   2,  6,  8,  8,  6,  2,   0,
  - 3,   2,  6,  8,  8,  6,  2, - 3,
  - 5,   2,  3,  6,  6, 3,   2, - 5,
  -10,   2,  4,  4,  4, 4,   2, -10,
  -10,  -8,  0,  0,  0, 0,  -8, -10);
onside:array[0..63] of byte=
(
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1,
0,0,0,2,2,1,1,1);

color:array[0..64] of byte=
(
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,
0,1,0,1,0,1,0,1,
1,0,1,0,1,0,1,0,2);


NILAI_NGGAKBISAROKADE=40;
NILAI_ROKADE=10;
//NILAI_SUDAHROKADE=10;
NILAI_BISHOP_TRAPPED=170;
NILAI_PION_PUSAT_BLOCKED=25;
NILAI_BENTENG_MENTRI_SEMI_OPEN_FILE_DEKAT_RAJA=15;
NILAI_BENTENG_SEMI_OPEN_FILE_DEKAT_RAJA=10;
NILAI_BENTENG_OPEN_FILE_DEKAT_RAJA=7;
NILAI_KUDA_POSISI_TERTUTUP:array[0..8] of integer=(0,0,0,5,35,40,45,47,50);

NILAI_BENTENG_TUMPUK_KOLOM=4;
NILAI_BENTENG_TUMPUK_KOLOM_DEKAT_RAJA=10;
NILAI_BENTENG_MENTRI_OPEN=3;
NILAI_BENTENG_MENTRI_OPEN_DEKAT_RAJA=5;
NILAI_BENTENG_MENTRI_SEMI_OPEN=2;
NILAI_BENTENG_TUMPUK_KOLOM_OPEN=10;
NILAI_PION_TUMPUK=10;
NILAI_PION_TERISOLASI:array[0..7] of byte=(3,6,8,8,8,8,6,3);
NILAI_BENTENG_BARIS7=15;
NILAI_BENTENG_BARIS8=4;
NILAI_BENTENG_TUMPUK_BARIS7=4;
NILAI_BENTENG_BLOCKED=10;
NILAI_PION_BEBAS:array[0..7] of byte=(10,12,14,16,16,14,12,10);
NILAI_MOBILITY=2;
NILAI_TROPISM_MENTRI=2;
NILAI_TROPISM_GAJAH=1;
NILAI_TROPISM_KUDA=1;
NILAI_BLOCKED_PAWN=7;
NILAI_PION_BEBAS_CONNECTED=50;
NILAI_BISHOP_PAIR0=20;
NILAI_BISHOP_PAIR1=12;
NILAI_NO_PAWN=70;
NILAI_NO_FIANCHETTO=5;
NILAI_ANOTHER_WEAK_STRUCTURE=4;
NILAI_KNIGHT_LACK_MOBILITY:array[0..8] of shortint=(-25,-7,0,0,0,0,0,0,0);
//NILAI_BISHOP_FIANCHETTO=10;

NILAI_MOBILITY_GAJAH:array[0..14] of shortint=
(-4,-2,0,1,3,6,8,10,12,14,16,18,20,22,24);

NILAI_SEMI_OPEN_FILE:array[0..7] of integer=
(1,2,3,5,5,3,2,1);
NILAI_OPEN_FILE:array[0..7] of integer=
(2,3,5,7,7,5,3,2);
w_nilai_pion_advance_bebas:array[1..7] of integer
  =(0,2,5,35,75,155,0);
b_nilai_pion_advance_bebas:array[0..6] of integer
  =(0,155,75,35,5,2,0);
w_nilai_benteng_dibelakang_pion_bebas:array[1..7] of integer
  =(0,0,10,15,25,35,0);
b_nilai_benteng_dibelakang_pion_bebas:array[0..6] of integer
  =(0,35,25,15,10,0,0);
b_nilai_pion_advance_bebas_blocked:array[0..6] of integer
  =(0,25,19,10,5,2,0);
w_nilai_pion_advance_bebas_blocked:array[1..7] of integer
  =(0,2,5,10,19,25,0);
w_nilai_pion_bebas_didukung_raja:array[1..7] of integer
  =(0,0,0,10,25,50,0);
b_nilai_pion_bebas_didukung_raja:array[0..6] of integer
  =(0,50,25,10,0,0,0);

nilai_bishop_blocked:array[0..8] of integer=(0,2,5,12,30,50,70,100,100);
nilai_pawn_shield:array[0..14] of integer=(0,8,15,30,50,70,80,90,120,130,140,150,170,180,200);
nilai_pawn_ram:array[0..8] of integer=(0,0,0,5,12,35,40,45,50);
nilai_king_pressure:array[0..20] of integer=(0,0,2,4,8,15,30,65,80,100,125,150,175,200,225,250,300,325,350,400,500);

nilai_endgame_scale:array[0..31] of byte=
(100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,100,80,70,60,50, {21}
40,30,20,20,10,10,10,0,0,0);

function popcount_w(p:pword):integer;
var n:integer;
begin
  inc(p);
  n:=mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];
  result:=n;
end;

function popcount_b(p:pword):integer;
var n:integer;
begin
  n:=mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];
  result:=n;
end;

function popcount(p:pword):integer;
var n:integer;
begin
  n:=mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];
  inc(p);
  n:=n+mobmask[p^];

  result:=n;
end;

function isdraw(data:tdata;giliran:integer):boolean;
var c,pos,pos2:integer;
begin
  result:=false;
  if (data.pawnblack=0) and (data.pawnwhite=0) then
  begin
      if data.nilai_perwira_putih=0 then
      begin
        if (data.nilai_perwira_hitam<=3) then
        begin
          result:=true;exit;
        end;
        if (data.nilai_perwira_hitam=6) and (data.bishopblack=0) then
        begin
          result:=true;exit;
        end;
      end;
      if data.nilai_perwira_hitam=0 then
      begin
        if (data.nilai_perwira_putih<=3) then
        begin
          result:=true;exit;
        end;
        if (data.nilai_perwira_putih=6) and (data.bishopwhite=0) then
        begin
          result:=true;exit;
        end;
      end;
      if (data.nilai_perwira_putih=data.nilai_perwira_hitam) then
      begin
        if (data.nilai_perwira_putih=3) then
        begin
          result:=true;exit;
        end;
        if (data.nilai_perwira_putih=6) and
        (data.bishopblack=0) and (data.bishopwhite=0) then
        begin
          result:=true;exit;
        end;
      end;
      if (data.nilai_perwira_putih-data.nilai_perwira_hitam=3)
      and (data.nilai_perwira_putih=6) and (data.bishopwhite=0) then
      begin
        result:=true;exit;
      end;
      if (data.nilai_perwira_hitam-data.nilai_perwira_putih=3)
      and (data.nilai_perwira_hitam=6) and (data.bishopblack=0) then
      begin
        result:=true;exit;
      end;
  end;
end;

function dynamiclazy(var data:tdata):integer;
begin
  result:=0;
    if data.queenblack=0 then dec(result,80);
    if data.queenwhite=0 then dec(result,80);
    if data.rookblack=0 then dec(result,50);
    if data.rookwhite=0 then dec(result,50);
    if data.knightblack=0 then dec(result,30);
    if data.knightwhite=0 then dec(result,30);

end;

function eval;
var nilai:integer;
attack,piecepos:int64;pos,h:integer;
tempb,tempb2:boolean;
temp,tempx,tempi,temp2:integer;
horattack,verattack:int64;
early_endgame,endgame:boolean;
posrajaputih,posrajahitam:integer;
pawnwattack,pawnbattack:int64;
temp64,tempk64:int64;
xrajaputih,yrajaputih,xrajahitam,yrajahitam:integer;
filerajaputih,filerajahitam,pionbebasputih,pionbebashitam,pawnram:integer;
kingotherside:boolean;
m1,m2,m3:integer;
blackkingpressure,whitekingpressure,m,posgajah:integer;
whitekingattack,blackkingattack:int64;
allp,allp90,allpa8,allph8:int64;
begin

  if isdraw(data,giliran) then
  begin
    result:=-CONTEMP_DRAW;exit;
  end;

  {sistem penilaian yang digunakan di fungsi ini adalah jika ada sesuatu yang menguntungkan putih
   maka variabel 'nilai' ditambah, sebaliknya jika menguntungkan hitam maka variabel 'nilai' dikurangi}
  nilai:=data.materialscore;

  {jika gajah terletak pada petak h7 dan ada pion lawan pada petak g7 ata g6 dan petak f7, maka
  gajah itu terperangkap}
  IF (data.papan[h7]=_GAJAHPUTIH) AND ((data.papan[g7]=_PIONHITAM) or (data.papan[g6]=_PIONHITAM))
  AND (data.papan[f7]=_PIONHITAM) THEN
        dec(nilai,NILAI_BISHOP_TRAPPED);
  IF (data.papan[a7]=_GAJAHPUTIH) AND ((data.papan[b7]=_PIONHITAM) or (data.papan[b6]=_PIONHITAM))
  AND (data.papan[c7]=_PIONHITAM) THEN
        dec(nilai,NILAI_BISHOP_TRAPPED);
  IF (data.papan[h2]=_GAJAHHITAM) AND ((data.papan[g2]=_PIONPUTIH) or (data.papan[g3]=_PIONPUTIH))
  AND (data.papan[f2]=_PIONPUTIH) THEN
        inc(nilai,NILAI_BISHOP_TRAPPED);
  IF (data.papan[a2]=_GAJAHHITAM) AND ((data.papan[b2]=_PIONPUTIH) or (data.papan[b3]=_PIONPUTIH))
  AND (data.papan[c2]=_PIONPUTIH) THEN
        inc(nilai,NILAI_BISHOP_TRAPPED);


  m1:=nilai;
  early_endgame:=(data.nilai_perwira_putih<=17) or (data.nilai_perwira_hitam<=17);
  endgame:=(data.nilai_perwira_putih<=12) and (data.nilai_perwira_hitam<=12);

  //checkpoint pertama dari lazy eval, dalam program ini digunakan tiga lazy checkpoint
  //dimana semakin ke dalam margin yang digunakan semakin kecil
  if lazyOK then
  begin
    {tentukan nilai lazy margin berdasarkan material yang masih tersisa pada papan,
     semakin sedikit material yang tersisa maka risiko semakin berkurang sehingga margin diperkecil}
    m:=dynamiclazy(data);
    {namun jika sudah endgame maka dibutuhkan margin yang besar dikarenakan adanya evaluasi pion bebas}
    if endgame then inc(m,400)
    else if early_endgame then inc(m,150);
    if ai_side=_SISIPUTIH then
    begin
      temp:=nilai;
    end else
    begin
      temp:=-nilai;
    end;
    if temp+LAZY_MARGIN1a+m<alpha then
    begin
      eval:=temp;inc(lazyexit);
      exit;
    end;
    if temp-LAZY_MARGIN1a-m>beta then
    begin
      eval:=temp;inc(lazyexit);
      exit;
    end;

  end;

  whitekingpressure:=0;blackkingpressure:=0;
  allp:=data.allpieces;
  allp90:=data.allpiecesr90;
  allpa8:=data.allpiecesa8h1;
  allph8:=data.allpiecesh8a1;


  pawnwattack:=0;pawnbattack:=0;
  pionbebasputih:=0;pionbebashitam:=0;
//  knightwattack:=0;knightbattack:=0;
  pawnram:=0;

  posrajahitam:=lastbitp(@data.kingblack);
  posrajaputih:=firstbitp(@data.kingwhite);
  filerajaputih:=poshorizmask[posrajaputih];
  filerajahitam:=poshorizmask[posrajahitam];
  kingotherside:=(abs(filerajaputih-filerajahitam)>2);
  whitekingattack:=kingmask[posrajaputih] or data.kingwhite;
  blackkingattack:=kingmask[posrajahitam] or data.kingblack;

  {cek status rokade}
  if not data.bc and (data.flagrokade and bithitamnoc=0) then
  begin
     {jika sudah kehilangan hak rokade namun belum rokade,
     maka nilainya dikurangi. Jika mentri lawan sudah nggak ada maka pengurangannya adalah
     setengah dari yg seharusnya}
     if data.queenwhite<>0 then
       inc(nilai,NILAI_NGGAKBISAROKADE)
     else
       inc(nilai,NILAI_NGGAKBISAROKADE shr 1);
  end else if data.bc then dec(nilai,NILAI_ROKADE);

  if not data.wc and (data.flagrokade and bitputihnoc=0) then
  begin
    if data.queenblack<>0 then
     dec(nilai,NILAI_NGGAKBISAROKADE)
    else
     dec(nilai,NILAI_NGGAKBISAROKADE shr 1)
  end
  else if data.wc then inc(nilai,NILAI_ROKADE);

  //mengevaluasi formasi pion di depan raja putih
  //hanya dilakukan jika mentri hitam masih ada
  if (data.queenblack<>0) and not endgame then
  begin
    temp:=0;
    //jika raja putih berada pada sayap raja
    //tingkat kerusakan disimpan dalam variabel temp, semakin besar berarti formasi pion semakin rusak
    if (filerajaputih>=5) then
    begin
        //jika pion kolom ke-7 nggak ada maka kerusakan cukup parah
        if file_mask[6] and data.pawnwhite = 0 then
        begin
          inc(temp,3);
          //jika pion lawan pada kolom ke-7 juga nggak ada, maka kerusakannya lebih parah lagi
          //karena kolom itu dapat dengan mudah dimanfaatkan buah lawan untuk langsung menyerang raja
          if file_mask[6] and data.pawnblack = 0 then inc(temp,1);
        end else
        begin
          //jika pion kolom ke-7 masih ada namun sudah maju 2 petak maka formasi pion juga rusak
          if (data.papan[14]<>_PIONPUTIH) and (data.papan[22]<>_PIONPUTIH) then inc(temp,2);
        end;
        //lakukan hal yang sama untuk kolom ke-8
        if file_mask[7] and data.pawnwhite = 0 then
        begin
          inc(temp,3);
          if file_mask[7] and data.pawnblack = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[15]<>_PIONPUTIH) and (data.papan[23]<>_PIONPUTIH) then inc(temp,2);
        end;
        //namun kolom ke-6 tidak terlalu berpengaruh karenanya hanya dicek apakah
        //masih ada pion atau tidak
        if file_mask[5] and data.pawnwhite=0 then inc(temp,2);
        //jika sudah tidak ada pion putih pada petak g2 dan h2 maka ada sedikit kerusakan
        if (data.papan[g2]<>_PIONPUTIH) and (data.papan[h2]<>_PIONPUTIH) then
        begin
         inc(temp);
         //jika pion f2 juga sudah nggak ada maka tingkat kerusakan sedikit lebih parah
         if (data.papan[f2]<>_PIONPUTIH) then inc(temp);
        end;
        //jika tidak ada pion atau gajag pada petak g2 maka ada kerusakan
        //karena terdapat celah pada g2 yang dapat dimanfaatkan lawan
        if (data.papan[g2]<>_GAJAHPUTIH) and (data.papan[g2]<>_PIONPUTIH) then
         dec(nilai,NILAI_NO_FIANCHETTO);
        //jika petak f2 dan h2 nggak ada pion putih maka ada kelemahan pada petak g3 yang
        //dapat dimanfaatkan lawan (terutama kuda / mentri)
        if (data.papan[f2]<>_PIONPUTIH) and (data.papan[h2]<>_PIONPUTIH) then
         dec(nilai,NILAI_ANOTHER_WEAK_STRUCTURE);

        dec(nilai,nilai_pawn_shield[temp]);
//        if (data.papan[g2]=0)
    end  //posrajaputih mod 8 >=4
    else
    //lakukan hal yg sama jika raja pada sayap mentri
    if filerajaputih<=3 then
    begin
        if file_mask[0] and data.pawnwhite = 0 then
        begin
          inc(temp,3);
          if file_mask[0] and data.pawnblack = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[8]<>_PIONPUTIH) and (data.papan[16]<>_PIONPUTIH) then inc(temp,2);
        end;
        if file_mask[1] and data.pawnwhite = 0 then
        begin
          inc(temp,3);
          if file_mask[1] and data.pawnblack = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[9]<>_PIONPUTIH) and (data.papan[17]<>_PIONPUTIH) then inc(temp,2);
        end;
        if file_mask[2] and data.pawnwhite = 0 then
        begin
          inc(temp,2);
        end;
        if (data.papan[a2]<>_PIONPUTIH) and (data.papan[b2]=_PIONPUTIH) then
        begin
         inc(temp);
         if (data.papan[c2]=_PIONPUTIH) then inc(temp);
        end;
        if (data.papan[b2]<>_GAJAHPUTIH) and (data.papan[b2]<>_PIONPUTIH) then
         dec(nilai,NILAI_NO_FIANCHETTO);
        if (data.papan[a2]<>_PIONPUTIH) and (data.papan[c2]<>_PIONPUTIH) then
         dec(nilai,NILAI_ANOTHER_WEAK_STRUCTURE);


        dec(nilai,nilai_pawn_shield[temp]);

    end//sudah rokade
    else
    begin
      //jika raja berada pada tengah papan
      tempx:=filerajaputih;
      if tempx>0 then
      begin
        //cek apakah pada kolom di kiri raja ada pion yg melindungi, jika tidak maka
        //terdapat kerusakan
        if file_mask[tempx-1] and data.pawnwhite=0 then
        begin
          inc(temp,2);
        end;
      end;
      //cek apakah pada kolom raja ada pion yg melindungi, jika tidak maka
      //terdapat kerusakan
      if file_mask[tempx] and data.pawnwhite=0 then
      begin
          inc(temp,2);
      end;
      if tempx<7 then
      begin
        if file_mask[tempx+1] and data.pawnwhite=0 then
        begin
          inc(temp,2);
        end;
      end;
      dec(nilai,nilai_pawn_shield[temp]);
    end;
  end;

//mengevaluasi king safety hitam

  if (data.queenwhite<>0) and not endgame then
  begin
    temp:=0;
    if  (filerajahitam>=5)
    then
    begin
        if file_mask[6] and data.pawnblack = 0 then
        begin
          inc(temp,3);
          if file_mask[6] and data.pawnwhite = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[54]<>_PIONHITAM) and (data.papan[46]<>_PIONHITAM) then inc(temp,2);
        end;
        if file_mask[7] and data.pawnblack = 0 then
        begin
          inc(temp,3);
          if file_mask[7] and data.pawnwhite = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[55]<>_PIONHITAM) and (data.papan[47]<>_PIONHITAM) then inc(temp,2);
        end;
        if (data.papan[g7]<>_PIONHITAM) and (data.papan[h7]<>_PIONHITAM) then
        begin
         inc(temp);
         if (data.papan[f7]=0) then inc(temp);
        end;
        if (data.papan[g7]<>_PIONHITAM) and (data.papan[g7]<>_GAJAHHITAM) then
         inc(nilai,NILAI_NO_FIANCHETTO);
        if (data.papan[f7]<>_PIONHITAM) and (data.papan[h7]<>_PIONHITAM) then
         inc(nilai,NILAI_ANOTHER_WEAK_STRUCTURE);


        inc(nilai,nilai_pawn_shield[temp]);
    end  //posrajaputih mod 8 >=4
    else
    if filerajaputih<=3 then
    begin
        if file_mask[0] and data.pawnblack = 0 then
        begin
          inc(temp,3);
          if file_mask[0] and data.pawnwhite = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[48]<>_PIONHITAM) and (data.papan[40]<>_PIONHITAM) then inc(temp,2);
        end;
        if file_mask[1] and data.pawnblack = 0 then
        begin
          inc(temp,3);
          if file_mask[1] and data.pawnwhite = 0 then inc(temp,1);
        end else
        begin
          if (data.papan[49]<>_PIONHITAM) and (data.papan[41]<>_PIONHITAM) then inc(temp,2);
        end;
        if file_mask[2] and data.pawnblack = 0 then
        begin
          inc(temp,3);
        end else
        begin
          if (data.papan[50]<>_PIONHITAM) and (data.papan[42]<>_PIONHITAM) then inc(temp,2);
        end;
        if (data.papan[a7]<>_PIONHITAM) and (data.papan[b7]<>_PIONHITAM) then
        begin
         inc(temp);
         if (data.papan[c7]<>_PIONHITAM) then inc(temp);
        end;
        if (data.papan[b7]<>_PIONHITAM) and (data.papan[b7]<>_GAJAHHITAM) then
         inc(nilai,NILAI_NO_FIANCHETTO);
        if (data.papan[a7]<>_PIONHITAM) and (data.papan[c7]<>_PIONHITAM) then
         inc(nilai,NILAI_ANOTHER_WEAK_STRUCTURE);


        inc(nilai,nilai_pawn_shield[temp]);

    end
    else
    begin
      if filerajahitam>0 then
      begin
        if file_mask[filerajahitam-1] and data.pawnblack=0  then
        begin
          inc(temp,2);
        end;
      end;
      if file_mask[filerajahitam] and data.pawnblack=0  then
      begin
          inc(temp,2);
      end;
      if tempx<7 then
      begin
        if file_mask[filerajahitam+1] and data.pawnblack=0  then
        begin
          inc(temp,2);
        end;
      end;
      inc(nilai,nilai_pawn_shield[temp]);
    end;
  end;

  case popcount(@data.bishopblack) of
   1:
    begin
      //jika ada 1 gajah yang tersisa maka catat posisi gajah
      posgajah:=lastbitp(@data.bishopblack);
    end;
   2:
    begin
      posgajah:=64;
      //jika masih ada 2 gajah dan lawan tidak punya gajah maka merupakan suatu keuntungan
      //sehingga dikasih bonus
      if data.bishopblack=0 then
        inc(nilai,NILAI_BISHOP_PAIR0);
    end;
    else posgajah:=64;
  end;

  temp2:=0;
  piecepos:=data.pawnblack;
  while piecepos<>0 do
  begin
    pos:=lastbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];
    pawnbattack:=pawnbattack or b_pawn_attack[pos];
    dec(nilai,nilai_pos_pion_b[pos]);
    //hitung berapa banyak pion yg petaknya sewarna dengan petka gajah yg tersisa
    if color[pos]=color[posgajah] then inc(temp2);

    //kalau raja lawan berada pada sayap yang berlawanan maka kasih nilai bonus tambahan untuk pion
    //pada sayap raja lawan yang sudah maju agar dapat membongkar formasi pion lawan
    if (kingotherside) and (onside[pos]=onside[posrajaputih]) then
      dec(nilai,nilai_pos_pion_b[pos]);

    if (pos>=a7) and (data.papan[pos-8]=_PIONPUTIH) then
      inc(nilai,NILAI_BLOCKED_PAWN);

    //pendeteksian pion tumpuk dan pion terisolasi dengan menggunakan bitboard
    if rook_attack_down_mask[pos] and data.pawnblack <> 0 then
      inc(nilai,NILAI_PION_TUMPUK);
    if (pion_gantung_mask[pos] and data.pawnblack = 0) and (data.nilai_perwira_putih<>0) then
      inc(nilai,NILAI_PION_TERISOLASI[poshorizmask[pos]]);
    if b_pion_bebas_mask[pos] and data.pawnwhite = 0 then
    begin
      temp:=0;
      dec(nilai,NILAI_PION_BEBAS[pos mod 8]);


      tempx:=pos mod 8;
      pionbebashitam:=pionbebashitam or bit8mask[tempx];
      if (pos shr 3<=2) then
      begin
        if tempx>0 then
        begin
          //jika pion bebas sudah pada baris ke-6 dan disebelah kiri/kanannya ada pion bebas
          //lain maka kasih bonus tinggi karena kedua pion ini dapat saling melindungi
          if (pionbebashitam and bit8mask[tempx-1]<>0) and
          ((data.papan[pos-1]=_PIONHITAM) or (data.papan[pos+7]=_PIONHITAM)) then
            dec(temp,NILAI_PION_BEBAS_CONNECTED);
        end;
        if tempx<7 then
        begin
          if (pionbebashitam and bit8mask[tempx+1]<>0) and
          ((data.papan[pos+1]=_PIONHITAM) or (data.papan[pos+9]=_PIONHITAM)) then
            dec(temp,NILAI_PION_BEBAS_CONNECTED);
        end;
      end;

      //semakin dekat pion dengan petak promosi maka nilainya semakin tinggi
      dec(temp,b_nilai_pion_advance_bebas[pos shr 3]);

      verattack:=vertmask[pos,(data.allpiecesr90 shr vershiftmask[pos]) and 255] and rook_attack_up_mask[pos];
      //jika dibelakang pion bebeas ada  benteng kawan maka kasih bonus karena benteng itu dapat
      //melindungi laju promosi
      if verattack and data.rookblack <> 0 then
        dec(temp,b_nilai_benteng_dibelakang_pion_bebas[pos shr 3])
      else
      //sebaliknya jika dibelakang pion bebas ada benteng lawan maka kasih pinalti
      if verattack and data.rookwhite <> 0 then
        inc(temp,b_nilai_benteng_dibelakang_pion_bebas[pos shr 3]);

      //jika petak di depan pion bebas terdapat buah lawan maka kasih pinalti
      //karena buah lawan itu harus disingkirkan dulu
      //nilai pinalti tergantung seberapa dekat pion bebas itu dengan petak promosi
      //semakin dekat pinaltinya semakin besar. Logikanya memblok pion bebas yang hampir
      //promosi lebih baik daripada memblok pion bebas yang masih ditengah papan
      if (data.papan[pos-8]>0) then
        inc(temp,b_nilai_pion_advance_bebas_blocked[pos shr 3]);

      //jika di sekitar pion bebas ada raja kawan maka kasih bonus karena raja itu
      //dapat melindungi laju promosi. bonus itu tergantung pada seberapa dekat
      //pion bebas dengan petak promosi, semakin dekat bonusnya semakin besar.
      //logikanya, melindungi pion bebas yang hampir promosi lebih baik daripada
      //melindungi pion bebas yang masih di tengah papan

      if kingmask[pos] and data.kingblack<>0 then
        dec(temp,b_nilai_pion_bebas_didukung_raja[pos shr 3]);

      //nilai pion bebas diskalakan berdasarkan total nilai perwira lawan
      //semakin sedikit perwira lawan yang tersisa maka pion bebas semakin berbahaya
      //sebaliknya semakin banyak perwira lawan maka pion bebas semakin kurang berarti
      if temp>0 then
        inc(nilai,temp*nilai_endgame_scale[data.nilai_perwira_putih] div 100);

    end;
  end;
  //kurangi nilai sesuai dengan jumlah pion yang sewarna dengan warna sat-satunya gajah yg tersisa
  inc(nilai,nilai_badbishop[temp2]);
  tempk64:=pawnbattack and whitekingattack;
  inc(whitekingpressure,popcount(@tempk64));

  case popcount(@data.bishopwhite) of
   1:
    begin
      //jika ada 1 gajah yang tersisa maka catat posisi gajah
      posgajah:=firstbitp(@data.bishopwhite);
    end;
   2:
    begin
      posgajah:=64;
      //jika masih ada 2 gajah dan lawan tidak punya gajah maka merupakan suatu keuntungan
      //sehingga dikasih bonus
      if data.bishopblack=0 then
        inc(nilai,NILAI_BISHOP_PAIR0);
    end;
    else posgajah:=64;
  end;

  piecepos:=data.pawnwhite;
  temp2:=0;

  while piecepos<>0 do
  begin
    pos:=lastbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];
    pawnwattack:=pawnwattack or w_pawn_attack[pos];
    inc(nilai,nilai_pos_pion_w[pos]);

    if color[pos]=color[posgajah] then
      inc(temp2);

    //kalau raja lawan berada pada sayap yang berlawanan maka kasih nilai bonus tambahan untuk pion
    //pada sayap raja lawan yang sudah maju agar dapat membongkar formasi pion lawan
    if (kingotherside) and (onside[pos]=onside[posrajahitam]) then
      inc(nilai,nilai_pos_pion_w[pos]);

    if data.papan[pos+8]=_PIONHITAM then
    begin
      //nilai pawn ram mengindikasikan seberapa tertutup posisi
      inc(pawnram);
      //jika pion berada pada baris ke-2 dan didepannya ada pion lawan maka kurangi nilainya
      if (pos<=h2) then
        dec(nilai,NILAI_BLOCKED_PAWN);
    end;

    if rook_attack_up_mask[pos] and data.pawnwhite <> 0 then
      dec(nilai,NILAI_PION_TUMPUK);
    if (pion_gantung_mask[pos] and data.pawnwhite = 0) and (data.nilai_perwira_hitam<>0) then
      dec(nilai,NILAI_PION_TERISOLASI[poshorizmask[pos]]);

    if w_pion_bebas_mask[pos] and data.pawnblack = 0 then
    begin
      tempi:=0;
      inc(nilai,NILAI_PION_BEBAS[pos mod 8]);
      begin
        temp:=pos shr 3;
        tempx:=pos mod 8;
        pionbebasputih:=pionbebasputih or bit8mask[tempx];
        if (temp>=5) then
        begin
          if tempx>0 then
          begin
            if (pionbebasputih and bit8mask[tempx-1]<>0) and
            ((data.papan[pos-1]=_PIONPUTIH) or (data.papan[pos-9]=_PIONPUTIH)) then
              inc(tempi,NILAI_PION_BEBAS_CONNECTED);
          end;
          if tempx<7 then
          begin
            if (pionbebasputih and bit8mask[tempx+1]<>0) and
            ((data.papan[pos+1]=_PIONPUTIH) or (data.papan[pos-7]=_PIONPUTIH)) then
              inc(tempi,NILAI_PION_BEBAS_CONNECTED);
          end;
        end;

        inc(tempi,w_nilai_pion_advance_bebas[temp]);

        verattack:=vertmask[pos,(data.allpiecesr90 shr vershiftmask[pos]) and 255] and rook_attack_down_mask[pos];
        if  verattack and data.rookwhite <> 0 then
          inc(tempi,w_nilai_benteng_dibelakang_pion_bebas[temp])
        else
        if verattack and data.rookblack <> 0 then
          dec(tempi,w_nilai_benteng_dibelakang_pion_bebas[temp]);


        if (data.papan[pos+8]<0) then
          dec(tempi,w_nilai_pion_advance_bebas_blocked[temp]);

        if kingmask[pos] and data.kingwhite<>0 then
          inc(tempi,w_nilai_pion_bebas_didukung_raja[temp]);
      end;
      if tempi>0 then
        inc(nilai,tempi*nilai_endgame_scale[data.nilai_perwira_hitam] div 100);
    end;
  end;
  dec(nilai,nilai_badbishop[temp2]);

  tempk64:=pawnwattack and blackkingattack;
  inc(blackkingpressure,popcount(@tempk64));

  if ai_side=_SISIHITAM then inc(nilai,nilai_pawn_ram[pawnram])
  else dec(nilai,nilai_pawn_ram[pawnram]);

  m2:=nilai;
  if lazyOK then
  begin
    if ai_side=_SISIPUTIH then temp:=nilai else temp:=-nilai;
    if temp+LAZY_MARGIN2a<alpha then
    begin
      eval:=temp;inc(lazyexit);
      exit;
    end;
    if temp-LAZY_MARGIN2a>beta then
    begin
      eval:=temp;inc(lazyexit);
      exit;
    end;
  end;

  piecepos:=data.rookwhite;
  while piecepos<>0 do
  begin
    pos:=firstbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];

    //mendapatkan attack table dr benteng
    horattack:=horzmask[pos,(data.allpieces shr horshiftmask[pos]) and 255];
    verattack:=vertmask[pos,(data.allpiecesr90 shr vershiftmask[pos]) and 255];
    data.allpieces:=data.allpieces and not bit2nmask[pos];
    data.allpiecesr90:=data.allpiecesr90 and not bit2nmask90[pos];

    attack:=horattack or verattack;

    tempk64:=attack and blackkingattack;
    //nilai blackkingpressure mengindikasikan seberapa banyak petak di sekitar raja lawan
    //yang diserang oleh benteng ini
    inc(blackkingpressure,popcount(@tempk64));

    inc(nilai,NILAI_POS_BENTENG[pos]);

    //jika di depan benteng tidak ada pion kawan maka disebut sebagai semi open file / lajur setengah
    //terbuka
    if rook_attack_up_mask[pos] and data.pawnwhite =0 then
    begin
      inc(nilai,NILAI_SEMI_OPEN_FILE[pos mod 8]);
      //lajur setengah terbuka di sekitar raja lawan lebih berbahaya maka dikasih bonus
      tempb2:=(onside[posrajahitam]=onside[pos]) or(abs((pos mod 8)-(posrajahitam mod 8)) <=1);
      if tempb2 then
        inc(nilai,NILAI_BENTENG_SEMI_OPEN_FILE_DEKAT_RAJA);
      tempb:=false;
      //benteng tumpuk pada lajur setengah terbuka lebih bagus maka dikasih bonus
      if rook_attack_up_mask[pos] and data.rookwhite <> 0 then
      begin
        inc(nilai,NILAI_BENTENG_TUMPUK_KOLOM);
        tempb:=true;
      end;
      //jika di depan / belakang benteng ada mentri kawan maka dikasih bonus lagi
      if verattack and data.queenwhite <> 0 then
      begin
        inc(nilai,NILAI_BENTENG_MENTRI_SEMI_OPEN);
        if tempb2 then
          inc(nilai,NILAI_BENTENG_MENTRI_SEMI_OPEN_FILE_DEKAT_RAJA);
        tempb:=true;
      end;
     //jika di depan benteng tidak ada pion lawan ataupun kawan maka disebut lajur terbuka / open file
      if rook_attack_up_mask[pos] and data.pawnblack = 0 then
      begin
        //dikasih bonus
        inc(nilai,NILAI_OPEN_FILE[pos mod 8]);
        //jika menguasai jalur terbuka dan di dukung mentri maka kasih bonus lagi
        if rook_attack_down_mask[pos] and data.queenwhite <> 0 then
        begin
          inc(nilai,NILAI_BENTENG_MENTRI_OPEN);
          if tempb2 then
            inc(nilai,NILAI_BENTENG_MENTRI_OPEN_DEKAT_RAJA);

        end;

        //jika menguasai lajur terbuka yang didekat raja lawan maka dikasih bonus lagi
        if tempb2 then
          inc(nilai,NILAI_BENTENG_OPEN_FILE_DEKAT_RAJA);

        //kasih bonus untuk benteng tumpuk pada lajur terbuka
        if tempb then inc(nilai,NILAI_BENTENG_TUMPUK_KOLOM_OPEN);
        //kasih bonus tambahan untuk benteng tumpuk pada lajur terbuka dekat raja lawan
        if tempb and tempb2 then inc(nilai,NILAI_BENTENG_TUMPUK_KOLOM_DEKAT_RAJA);
      end;
    end;

    //jika benteng berada pada baris ke-7 dan masih ada pion lawan pada baris ke-7 atau
    //raja lawan masih ada pada baris ke-8 maka dikasih bonus
    if (pos shr 3 = 6) and ((rank_mask[6] and data.pawnblack<>0) or (rank_mask[7] and data.kingblack<>0)) then
    begin
      //jika ada dua benteng pada baris ke-7 maka dikasih bonus
      if horattack and data.rookwhite <> 0 then
         inc(nilai,NILAI_BENTENG_TUMPUK_BARIS7);
     //jika ada benteng dan mentri pada baris ke-7 maka dikasih bonus
      if horattack and data.queenwhite <> 0 then
         inc(nilai,NILAI_BENTENG_TUMPUK_BARIS7);
      //kasih bonus untuk benteng pada baris ke-7
      inc(nilai,NILAI_BENTENG_BARIS7);
    end else
    //jika benteng berada pada baris ke-8 maka juga dikasih bonus
    if pos shr 3 = 7 then
      inc(nilai,NILAI_BENTENG_BARIS8);

    //jika benteng sama sekali tidak dapat bergerak scr horizontal maka dikasih pinalti
    h:=pos mod 8;
    if (h=0) then
    begin
      if (data.papan[pos+1]<>0) then
        dec(nilai,NILAI_BENTENG_BLOCKED)
    end
    else if (h=7) then
    begin
      if (data.papan[pos-1]<>0) then
        dec(nilai,NILAI_BENTENG_BLOCKED)
    end
    else if (data.papan[pos-1]>0) and (data.papan[pos+1]>0) then
      dec(nilai,NILAI_BENTENG_BLOCKED);

  end;

  piecepos:=data.rookblack;
  while piecepos<>0 do
  begin
    pos:=lastbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];

    horattack:=horzmask[pos,(allp shr horshiftmask[pos]) and 255];
    verattack:=vertmask[pos,(allp90 shr vershiftmask[pos]) and 255];
    attack:=horattack or verattack;

    allp:=allp and not bit2nmask[pos];
    allp90:=allp90 and not bit2nmask90[pos];

    tempk64:=attack and whitekingattack;
    inc(whitekingpressure,popcount(@tempk64));

    dec(nilai,NILAI_POS_BENTENG[pos]);

    if rook_attack_down_mask[pos] and data.pawnblack =0 then
    begin
      dec(nilai,NILAI_SEMI_OPEN_FILE[pos mod 8]);
      tempb2:=(onside[posrajaputih]=onside[pos]) or(abs((pos mod 8)-(posrajaputih mod 8))<=1);
      if tempb2 then
        dec(nilai,NILAI_BENTENG_SEMI_OPEN_FILE_DEKAT_RAJA);

      tempb:=false;
      if verattack and data.queenblack <> 0 then
      begin
        dec(nilai,NILAI_BENTENG_MENTRI_SEMI_OPEN);
        if tempb2 then
          dec(nilai,NILAI_BENTENG_MENTRI_SEMI_OPEN_FILE_DEKAT_RAJA);
        tempb:=true;
      end;
      if rook_attack_down_mask[pos] and data.rookblack <> 0 then
      begin
        dec(nilai,NILAI_BENTENG_TUMPUK_KOLOM);
        tempb:=true;
      end;

      if rook_attack_down_mask[pos] and data.pawnwhite = 0 then
      begin
        dec(nilai,NILAI_OPEN_FILE[pos mod 8]);
        if rook_attack_up_mask[pos] and data.queenblack <> 0 then
        begin
          dec(nilai,NILAI_BENTENG_MENTRI_OPEN);
          if tempb2 then
            dec(nilai,NILAI_BENTENG_MENTRI_OPEN_DEKAT_RAJA);
        end;

        if tempb2 then
          dec(nilai,NILAI_BENTENG_OPEN_FILE_DEKAT_RAJA);

        if tempb then dec(nilai,NILAI_BENTENG_TUMPUK_KOLOM_OPEN);
        if tempb and tempb2 then dec(nilai,NILAI_BENTENG_TUMPUK_KOLOM_DEKAT_RAJA);
      end;
    end;

    if (pos shr 3 = 1) and ((rank_mask[1] and data.pawnwhite<>0) or (rank_mask[0] and data.kingwhite<>0)) then
    begin
      dec(nilai,NILAI_BENTENG_BARIS7);
      if horattack and data.rookblack<>0 then
        dec(nilai,NILAI_BENTENG_TUMPUK_BARIS7);
      if horattack and data.queenblack<>0 then
        dec(nilai,NILAI_BENTENG_TUMPUK_BARIS7);

    end else
    if pos shr 3 = 0 then
      dec(nilai,NILAI_BENTENG_BARIS8);

    h:=pos mod 8;
    if (h=0) then
    begin
      if (data.papan[pos+1]<>0) then
        inc(nilai,NILAI_BENTENG_BLOCKED)
    end
    else if (h=7) then
    begin
      if (data.papan[pos-1]<>0) then
        inc(nilai,NILAI_BENTENG_BLOCKED)
    end
    else if (data.papan[pos-1]<0) and (data.papan[pos+1]<0) then
      inc(nilai,NILAI_BENTENG_BLOCKED);

  end;

  //mengevaluasi kuda putih
  piecepos:=data.knightwhite;
  while piecepos<>0 do
  begin
    pos:=firstbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];
    inc(nilai,NILAI_POS_KUDA_W[pos]);
    //jika masih belum endgame maka kasih bonus untuk semakin dekat kuda ke raja lawan
    if not endgame then inc(nilai,tabel_edistance[pos,posrajahitam]*NILAI_TROPISM_KUDA);
    //jika berada dalam posisi tertutup maka kasih bonus
    //karena kuda lebih berharga daripada gajah dalam posisi tertutup
    inc(nilai,NILAI_KUDA_POSISI_TERTUTUP[pawnram]);

    attack:=knightmask[pos];
    temp64:=attack and not pawnbattack and not data.whitepieces;
    //jika kuda kehilangan petak yang aman untuk melangkah maka kasih pinalti
    inc(nilai,nilai_knight_lack_mobility[popcount(@temp64)]);

    //hitung berapa banyak petak di sekitar raja lawan yang diserang kuda ini
    tempk64:=attack and blackkingattack;
    inc(blackkingpressure,popcount(@tempk64));

    //jika kuda tidak menyerang perwira lawan dan dapat diusir oleh pion lawan
    //dalam satu langkah maka kuda itu berada dalam posisi yg jelek shg nilainya dikurangi
    if (pos>=a4) and (pos<=h5) and(attack and (data.blackpieces and not data.pawnblack)=0) and
    (NILAI_POS_KUDA_W[pos]>0)
    then
    begin
      tempx:=pos mod 8;
      if ((data.papan[pos+17]=_pionhitam) and (data.papan[pos+9]=0) and (tempx<7))
      or ((data.papan[pos+15]=_pionhitam) and (data.papan[pos+7]=0) and (tempx>0))
      then
         dec(nilai,NILAI_POS_KUDA_W[pos] shr 1);
    end;
    //jika kuda outpost yaitu kuda yg tidak mungkin dapat diusir pion lawan dan
    //didukung oleh pion maka nilainya ditambah
    IF (nilai_kuda_outpost_w[pos]>0) then
    begin
      IF (w_outpost_mask[pos] and data.pawnblack=0)
      THEN
      BEGIN
        temp64:=(b_pawn_attack[pos] and data.pawnwhite);
      //jika didukung 2 pion dikasih nilai penuh
      //jika cuma didukung 1 pion dikasih nilai separo
        case popcount(@temp64) of
        1 : inc(nilai,nilai_kuda_outpost_w[pos] shr 1);
        2 : inc(nilai,nilai_kuda_outpost_w[pos])
        end;
      END;
    end;

  end;

  piecepos:=data.knightblack;
  while piecepos<>0 do
  begin
    pos:=lastbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];
    dec(nilai,NILAI_POS_KUDA_B[pos]);
    if not endgame then dec(nilai,tabel_edistance[pos,posrajaputih]*NILAI_TROPISM_KUDA);
    dec(nilai,NILAI_KUDA_POSISI_TERTUTUP[pawnram]);

    attack:=knightmask[pos];
    temp64:=attack and not pawnwattack and not data.blackpieces;
    dec(nilai,nilai_knight_lack_mobility[popcount(@temp64)]);

    tempk64:=attack and whitekingattack;
    inc(whitekingpressure,popcount(@tempk64));

    if  (pos>=a4) and (pos<=h5) and (attack and (data.whitepieces and not data.pawnwhite)=0) and
    (NILAI_POS_KUDA_B[pos]>0)
    then
    begin
      if ((data.papan[pos-17]=_PIONPUTIH) and (data.papan[pos-9]=0))
      or ((data.papan[pos-15]=_PIONPUTIH) and (data.papan[pos-7]=0))
      then
         inc(nilai,NILAI_POS_KUDA_B[pos] shr 1);
    end;

    IF (nilai_kuda_outpost_b[pos]>0) then
    begin
      IF (b_outpost_mask[pos] and data.pawnwhite=0)
      THEN
      BEGIN
        temp64:=(w_pawn_attack[pos] and data.pawnblack);
        case popcount(@temp64) of
        1 : dec(nilai,nilai_kuda_outpost_w[pos] shr 1);
        2 : dec(nilai,nilai_kuda_outpost_w[pos])
        end;
      END;
    end;

  end;
  {lazy checkpoint ke-3}
  m3:=nilai;
  if lazyOK then
  begin
    if ai_side=_SISIPUTIH then temp:=nilai else temp:=-nilai;
    if temp+LAZY_MARGIN3a<alpha then
    begin
      eval:=temp;inc(lazyexit);
      exit;
    end;
    if temp-LAZY_MARGIN3a>beta then
    begin
      eval:=temp;inc(lazyexit);
      exit;
    end;
  end;


  //mengevaluasi gajah putih
  piecepos:=data.bishopwhite;
  while piecepos<>0 do
  begin

    pos:=firstbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];

    {cari attack table}
    attack:=diaga8h1mask[pos,(data.allpiecesa8h1 shr a8h1shiftmask[pos]) and (anda8h1mask[pos])];
    attack:=attack or diagh8a1mask[pos,(data.allpiecesh8a1 shr h8a1shiftmask[pos]) and (andh8a1mask[pos])];
    data.allpiecesa8h1:=data.allpiecesa8h1 and not bit2nmaska8h1[pos];
    data.allpiecesh8a1:=data.allpiecesh8a1 and not bit2nmaskh8a1[pos];

    {hitung mobility}
    temp64:=attack and not data.whitepieces;
    inc(nilai,nilai_mobility_gajah[popcount_w(@temp64)]);

    {beri nilai minus jika ada pion yang terletak pada diagonal kiri atas dan kanan atas gajah,
     semakin banyak maka nilai minusnya semakin besar, karena pion itu menghalangi pergerakan gajah }
    temp64:=attack and bishop_attack_up_mask[pos] and data.pawnwhite;
    dec(nilai,nilai_bishop_blocked[popcount(@temp64)]);

    {hitung berapa banyak petak di sekitar raja lawan yang diserang oleh gajah ini}
    tempk64:=attack and blackkingattack;
    inc(blackkingpressure,popcount(@tempk64));

    {jika gajah outpost maka tambah nilainya}
    IF (nilai_gajah_outpost_w[pos]>0) AND
       (b_pawn_attack[pos] and data.pawnwhite<>0)
        AND
       (w_outpost_mask[pos] and data.pawnblack =0)
    THEN
    BEGIN
        inc(nilai,nilai_gajah_outpost_w[pos])

    END;

    inc(nilai,NILAI_POS_GAJAH_W[pos]);
    //if not endgame then inc(nilai,tabel_distance_gajah[pos,posrajahitam]*NILAI_TROPISM_GAJAH);

  end;


  piecepos:=data.bishopblack;

  while piecepos<>0 do
  begin

    pos:=lastbitp(@piecepos);
    piecepos:=piecepos and bit2nmasknot[pos];

    dec(nilai,NILAI_POS_GAJAH_B[pos]);
    //if not endgame then dec(nilai,tabel_distance_gajah[pos,posrajaputih]*NILAI_TROPISM_GAJAH);

    attack:=diaga8h1mask[pos,(allpa8 shr a8h1shiftmask[pos]) and (anda8h1mask[pos])];
//    bishopbattack:=bishopbattack or attack;
    attack:=attack or diagh8a1mask[pos,(allph8 shr h8a1shiftmask[pos]) and (andh8a1mask[pos])];

    allpa8:=allpa8 and not bit2nmaska8h1[pos];
    allph8:=allph8 and not bit2nmaskh8a1[pos];

    temp64:=attack and not data.blackpieces;
    dec(nilai,nilai_mobility_gajah[popcount_b(@temp64)]);

    temp64:=attack and bishop_attack_down_mask[pos] and data.pawnblack;
    inc(nilai,nilai_bishop_blocked[popcount(@temp64)]);


    IF (nilai_gajah_outpost_b[pos]>0) AND
       (w_pawn_attack[pos] and data.pawnblack<>0) and 
       (b_outpost_mask[pos] and data.pawnwhite =0)
    THEN
    BEGIN
        dec(nilai,nilai_gajah_outpost_b[pos])
    END;

    tempk64:=attack and whitekingattack;
    inc(whitekingpressure,popcount(@tempk64));

  end;
  piecepos:=data.queenwhite;
  while piecepos<>0 do
  begin
    pos:=firstbitp(@piecepos);
    inc(nilai,NILAI_POS_MENTRI_W[pos]);

    attack:=diaga8h1mask[pos,(data.allpiecesa8h1 shr a8h1shiftmask[pos]) and (anda8h1mask[pos])];
    attack:=attack or diagh8a1mask[pos,(data.allpiecesh8a1 shr h8a1shiftmask[pos]) and (andh8a1mask[pos])];
    attack:=attack or horzmask[pos,(data.allpieces shr horshiftmask[pos]) and 255];
    attack:=attack or vertmask[pos,(data.allpiecesr90 shr vershiftmask[pos]) and 255];

    tempk64:=attack and blackkingattack;
    inc(blackkingpressure,popcount(@tempk64));

    piecepos:=piecepos and bit2nmasknot[pos];
    if not endgame then inc(nilai,tabel_edistance[pos,posrajahitam]*NILAI_TROPISM_MENTRI);

  end;

  piecepos:=data.queenblack;
  while piecepos<>0 do
  begin
    pos:=lastbitp(@piecepos);
    dec(nilai,NILAI_POS_MENTRI_B[pos]);
    attack:=diaga8h1mask[pos,(allpa8 shr a8h1shiftmask[pos]) and (anda8h1mask[pos])];
    attack:=attack or diagh8a1mask[pos,(allph8 shr h8a1shiftmask[pos]) and (andh8a1mask[pos])];
    attack:=attack or horzmask[pos,(allp shr horshiftmask[pos]) and 255];
    attack:=attack or vertmask[pos,(allp90 shr vershiftmask[pos]) and 255];

    tempk64:=attack and whitekingattack;
    inc(whitekingpressure,popcount(@tempk64));

    piecepos:=piecepos and bit2nmasknot[pos];
    if not endgame then dec(nilai,tabel_edistance[pos,posrajaputih]*NILAI_TROPISM_MENTRI);

  end;

  if not endgame then
  begin
    dec(nilai,nilai_pos_raja_w[posrajaputih]);
    inc(nilai,nilai_pos_raja_b[posrajahitam]);
    if data.queenwhite<>0 then
      inc(nilai,nilai_king_pressure[blackkingpressure]);
    if data.queenblack<>0 then
      dec(nilai,nilai_king_pressure[whitekingpressure]);
  end else
  begin
    temp64:=(data.pawnblack or data.pawnwhite);
    if (abcd_mask and temp64<>0) and (efgh_mask and temp64 <>0) then
    begin
      inc(nilai,nilai_pos_raja_endn_w[posrajaputih]);
      dec(nilai,nilai_pos_raja_endn_b[posrajahitam]);
    end else
    if abcd_mask and (temp64)<>0 then
    begin
      inc(nilai,nilai_pos_raja_endq_w[posrajaputih]);
      dec(nilai,nilai_pos_raja_endq_b[posrajahitam]);
    end else
    if efgh_mask and (temp64)<>0 then
    begin
      inc(nilai,nilai_pos_raja_endk_w[posrajaputih]);
      dec(nilai,nilai_pos_raja_endk_b[posrajahitam]);
    end else
    begin
      inc(nilai,nilai_pos_raja_endn_w[posrajaputih]);
      dec(nilai,nilai_pos_raja_endn_b[posrajahitam]);
    end;
  end;

  if (data.pawnwhite=0) then
    dec(nilai,NILAI_NO_PAWN);
  if (data.pawnblack=0)  then
    inc(nilai,NILAI_NO_PAWN);

  if (data.papan[d2]=_PIONPUTIH) then
  begin
    if (data.papan[d3]<>0) and (data.papan[c1]=_GAJAHPUTIH) then
      dec(nilai,NILAI_PION_PUSAT_BLOCKED);
  end;
  if (data.papan[e2]=_PIONPUTIH) then
  begin
    if (data.papan[e3]<>0) and (data.papan[f1]=_GAJAHPUTIH) then
      dec(nilai,NILAI_PION_PUSAT_BLOCKED);
  end;
  if (data.papan[d7]=_PIONHITAM) then
  begin
    if (data.papan[d6]<>0) and (data.papan[c8]=_GAJAHHITAM) then
      inc(nilai,NILAI_PION_PUSAT_BLOCKED);
  end;
  if (data.papan[e7]=_PIONHITAM) then
  begin
    if (data.papan[e6]<>0) and (data.papan[f8]=_GAJAHHITAM) then
      inc(nilai,NILAI_PION_PUSAT_BLOCKED);
  end;

  if abs(m1-nilai)>LAZY_MARGIN1a then
    lazy_margin1a:=abs(m1-nilai);
  if abs(m2-nilai)>LAZY_MARGIN2a then
    lazy_margin2a:=abs(m2-nilai);
  if abs(m3-nilai)>LAZY_MARGIN3a then
    lazy_margin3a:=abs(m3-nilai);

  if ai_side=_SISIPUTIH then eval:=nilai else eval:=-nilai;
end;

function materialvalue(ms:integer):integer;
begin
  if ai_side=_sisihitam then
    materialvalue:=-ms
  else
    materialvalue:=ms;
end;


end.
