unit Unit5;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TFormPromotion = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
  private
    { Private declarations }
  public
    promosi:integer;
    { Public declarations }
  end;

var
  FormPromotion: TFormPromotion;

implementation
  uses header;

{$R *.dfm}

procedure TFormPromotion.Button1Click(Sender: TObject);
begin
 promosi:=PROMOSI_MENTRI;
end;

procedure TFormPromotion.Button2Click(Sender: TObject);
begin
  promosi:=promosi_benteng;
end;

procedure TFormPromotion.Button3Click(Sender: TObject);
begin
 promosi:=PROMOSI_GAJAH;
end;

procedure TFormPromotion.Button4Click(Sender: TObject);
begin
 promosi:=PROMOSI_KUDA;
end;

end.
