object FormPromotion: TFormPromotion
  Left = 302
  Top = 250
  Width = 180
  Height = 126
  BorderIcons = []
  Caption = 'Promotion'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Button1: TButton
    Left = 17
    Top = 17
    Width = 65
    Height = 25
    Caption = 'Queen'
    Default = True
    ModalResult = 1
    TabOrder = 0
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 89
    Top = 17
    Width = 65
    Height = 25
    Caption = 'Rook'
    ModalResult = 1
    TabOrder = 1
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 17
    Top = 49
    Width = 65
    Height = 25
    Caption = 'Bishop'
    ModalResult = 1
    TabOrder = 2
    OnClick = Button3Click
  end
  object Button4: TButton
    Left = 89
    Top = 49
    Width = 65
    Height = 25
    Caption = 'Knight'
    ModalResult = 1
    TabOrder = 3
    OnClick = Button4Click
  end
end
