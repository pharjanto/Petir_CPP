unit test_suites;

interface
uses classes,header;
  type
  ttest=class(tthread)
      testfile:string;
      constructor create(testfile2:string);
      procedure execute;override;
      procedure terminated(sender:tobject);
  end;


procedure start_test(testfile:string);

implementation
uses customboard,unit1,windows,uiterative,hashing_header,unit7,unit3,sysutils,notation;
var anu:string;

constructor ttest.create;
begin
  freeonterminate:=true;
  onterminate:=terminated;
  testfile:=testfile2;
  inherited create(false);
end;

procedure parse_epd(s:string;var data:tdata;var giliran,answer:integer);
var p:integer;
ns,s2:string;  wtm:boolean;
a:integer;
begin
  anu:=s;
  fillchar(testanswer,sizeof(testanswer),0);
  p:=pos('bm',s);
  if p=0 then p:=pos('am',s);
  ns:=copy(s,1,p-1);
  readnotation(ns,data,wtm);
  if wtm then giliran:=_SISIPUTIH else giliran:=_SISIHITAM;
  fillbitboard(data);
  s:=copy(s,p+3,length(s)-(p+3));
  p:=pos(';',s);
  if p=0 then
  begin
    s:=s+';';
    p:=length(s);
  end;
  s:=copy(s,1,p-1);
  a:=1;

  while pos(' ',s)<>0 do
  begin
    s2:=copy(s,1,pos(' ',s)-1);
    if s2[length(s2)]='+' then s2:=copy(s2,1,length(s2)-1);
    ns:=shortnotationtolong(s2,data,giliran);
    testanswer[a]:=notationtomove(ns,data,giliran);
    inc(a);
    s:=copy(s,pos(' ',s)+1,length(s)-pos(' ',s));
  end;

  if s[length(s)]='+' then s:=copy(s,1,length(s)-1);
  ns:=shortnotationtolong(s,data,giliran);
  testanswer[a]:=notationtomove(ns,data,giliran);

end;


procedure analyze(data:tdata;giliran:integer);
  procedure init;
  var a,b:integer;
  begin
      cetc:=0;
      total_node:=0;
      ai_side:=giliran;
      hash_hit:=0;
      timepassed:=0;
      testsolved:=false;
      clockwhite:=realclock;
      clockblack:=realclock;
      lazy_margin1a:=lazy_margin1;
      lazy_margin2a:=lazy_margin2;
      lazy_margin3a:=lazy_margin3;
      lazyts:=0;

      fillchar(killer0,sizeof(killer0),_NO_MOVE);
      fillchar(killer1,sizeof(killer1),_NO_MOVE);

      cleartable;
      co_hash:=0;totalco:=0; hashco:=0;
      lazyexit:=0;
      fpruning:=0;efpruning:=0;razor:=0;
      cofirst:=0;
      computer_thinking:=true;

      for a:=-6 to 6 do
      for b:=0 to 67 do
      begin
        historyw[a,b]:=0;
        historyb[a,b]:=0;
      end;
//      fillchar(history,sizeof(history),0);
      for a:=1 to formiterative.StringGrid1.RowCount-1 do
      for b:=0 to formiterative.StringGrid1.colcount-1 do
        formiterative.StringGrid1.Cells[b,a]:='';
      startclock:=gettickcount;
      if usetimer then timelimit:=realclock;
  end;
var l:integer;
begin

  init;
  l:=toplevel;
  nilai:=iterative(toplevel,giliran,_NODEMAX,data);
  toplevel:=l;
end;

procedure parse_answer(ans:string);
begin
end;

procedure ttest.execute;
var f:textfile;
s:string;
data:tdata;giliran,answer,no,totalsolved,ref:integer;
tnode:int64;
begin
  runningTest:=true;
  form3.Memo1.Lines.clear;
  assignfile(f,testfile);
  reset(f);
  no:=0;totalsolved:=0;
  ref:=gettickcount;
  tnode:=0;
  timepassed:=0;timelimit:=999;
  while not eof(f) do
  begin
    readln(f,s);
    if s<>'' then
    begin
      inc(no);
      parse_epd(s,data,giliran,answer);
  //    form1.gambar(data,200);
      form3.Memo1.Lines.add('Problem #'+inttostr(no));
      analyze(data,giliran);
      inc(tnode,total_node);
      if testsolved then form3.Memo1.Lines[no-1]:='Problem #'+inttostr(no)+' solved'
      else form3.Memo1.Lines[no-1]:='Problem #'+inttostr(no)+' not solved';
      if testsolved then inc(totalsolved);
    end;
//    if no=2 then exit;
  end;
  ref:=gettickcount-ref;
  form3.Memo1.Lines.add('Total Problem solved: '+inttostr(totalsolved));
  form3.Memo1.Lines.add('Total time needed: '+inttostr(ref)+' ms');
  form3.Memo1.Lines.add('Total node: '+inttostr(tnode)+' node');
end;

procedure ttest.terminated;
begin
  runningtest:=false;
  form1.StatusBar1.Panels[3].Text:='';
end;

procedure start_test(testfile:string);
var t:ttest;
begin

  t:=ttest.create(testfile);
end;

end.
