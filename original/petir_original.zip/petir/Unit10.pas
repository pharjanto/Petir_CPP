unit Unit10;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TForm10 = class(TForm)
    RadioButton1: TRadioButton;
    Label1: TLabel;
    Edit1: TEdit;
    RadioButton2: TRadioButton;
    Label2: TLabel;
    Edit2: TEdit;
    RadioButton3: TRadioButton;
    Label3: TLabel;
    Edit3: TEdit;
    Label4: TLabel;
    Edit4: TEdit;
    RadioButton4: TRadioButton;
    Label5: TLabel;
    Edit5: TEdit;
    Label6: TLabel;
    Edit6: TEdit;
    Button1: TButton;
    Button2: TButton;
    procedure FormShow(Sender: TObject);
    procedure RadioButton2Click(Sender: TObject);
    procedure RadioButton3Click(Sender: TObject);
    procedure RadioButton4Click(Sender: TObject);
    procedure Edit2Click(Sender: TObject);
    procedure Edit1Click(Sender: TObject);
    procedure Edit3Click(Sender: TObject);
    procedure Edit5Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    stoutput:string;
    { Public declarations }
  end;

var
  Form10: TForm10;

implementation
  uses header;

{$R *.dfm}

procedure TForm10.FormShow(Sender: TObject);
begin
  case modetime of
    MINUTES_GAME :
    begin
      radiobutton1.Checked:=true;
      edit1.SetFocus;
    end;
    SECONDS_MOVE :
    begin
      radiobutton2.Checked:=true;
      edit2.SetFocus;
    end;
    MOVES_MINUTES :
    begin
      radiobutton3.Checked:=true;
      edit3.SetFocus;
    end;
    MINUTES_GAME_INCREMENT :
    begin
      radiobutton4.Checked:=true;
      edit5.SetFocus;
    end;


  end;
end;

procedure TForm10.RadioButton2Click(Sender: TObject);
begin
 edit2.SetFocus;
end;

procedure TForm10.RadioButton3Click(Sender: TObject);
begin
  edit3.setfocus;
end;

procedure TForm10.RadioButton4Click(Sender: TObject);
begin
  edit5.SetFocus;
end;

procedure TForm10.Edit2Click(Sender: TObject);
begin
 radiobutton2.Checked:=true;
end;

procedure TForm10.Edit1Click(Sender: TObject);
begin
  radiobutton1.Checked:=true;
end;

procedure TForm10.Edit3Click(Sender: TObject);
begin
  radiobutton3.Checked:=true;
end;

procedure TForm10.Edit5Click(Sender: TObject);
begin
  radiobutton4.Checked:=true;

end;

procedure TForm10.Button1Click(Sender: TObject);
begin
 if radiobutton1.checked then
 begin
   modetime:=MINUTES_GAME;
   clockwhite:=strtoint(edit1.text)*timefactor*60;
   clockblack:=clockwhite;
   stoutput:=edit1.text+' min / game';
 end else
 if radiobutton2.checked then
 begin
   modetime:=SECONDS_MOVE;
   realclock:=strtoint(edit2.text)*timefactor;
   clockwhite:=realclock;
   clockblack:=clockwhite;
   stoutput:=edit2.text+' sec / move';
 end else
 if radiobutton3.checked then
 begin
   modetime:=MOVES_MINUTES;
   rmoves:=strtoint(edit3.text);
   clockwhite:=strtoint(edit4.text)*timefactor*60;
   clockblack:=clockwhite;
   realclock:=clockwhite;
   stoutput:=edit3.text+' moves in '+edit4.text+' min';
 end else
 begin
   modetime:=MINUTES_GAME_INCREMENT;
   clockwhite:=strtoint(edit5.text)*timefactor*60;
   clockblack:=clockwhite;
   rincrement:=strtoint(edit6.text)*timefactor;
   stoutput:=edit5.text+' min / game +'+edit6.text;
 end;
end;

end.
