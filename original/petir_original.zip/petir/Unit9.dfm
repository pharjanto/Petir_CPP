object Form9: TForm9
  Left = 524
  Top = 9
  Width = 306
  Height = 459
  Caption = 'Input Move'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 20
    Top = 12
    Width = 100
    Height = 13
    Caption = 'Your Choosen Move:'
  end
  object Label2: TLabel
    Left = 20
    Top = 40
    Width = 79
    Height = 13
    Caption = 'Available Move :'
  end
  object Edit1: TEdit
    Left = 129
    Top = 8
    Width = 97
    Height = 21
    TabOrder = 0
  end
  object StringGrid1: TStringGrid
    Left = 20
    Top = 64
    Width = 258
    Height = 313
    DefaultColWidth = 50
    DefaultRowHeight = 18
    FixedCols = 0
    RowCount = 16
    FixedRows = 0
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Courier New'
    Font.Style = []
    Options = [goFixedVertLine, goFixedHorzLine, goDrawFocusSelected]
    ParentFont = False
    TabOrder = 1
    OnClick = StringGrid1Click
    OnDblClick = StringGrid1DblClick
  end
  object Button1: TButton
    Left = 63
    Top = 392
    Width = 75
    Height = 25
    Caption = 'OK'
    Default = True
    ModalResult = 1
    TabOrder = 2
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 159
    Top = 392
    Width = 75
    Height = 25
    Cancel = True
    Caption = 'Cancel'
    ModalResult = 2
    TabOrder = 3
  end
end
