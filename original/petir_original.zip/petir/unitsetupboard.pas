unit unitsetupboard;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, Buttons, Menus,udata,header;

const
	hand=11;
   remove=12;

type
  Tformsetupboard1 = class(TForm)
    Image2: TImage;
    PopupMenu1: TPopupMenu;
    ClearBoard1: TMenuItem;
    StartingPosition1: TMenuItem;
    Panel1: TPanel;
    Image1: TImage;
    GroupBox1: TGroupBox;
    SpeedButton1: TSpeedButton;
    SpeedButton2: TSpeedButton;
    SpeedButton3: TSpeedButton;
    SpeedButton4: TSpeedButton;
    SpeedButton5: TSpeedButton;
    SpeedButton6: TSpeedButton;
    SpeedButton7: TSpeedButton;
    SpeedButton8: TSpeedButton;
    SpeedButton9: TSpeedButton;
    SpeedButton10: TSpeedButton;
    SpeedButton11: TSpeedButton;
    SpeedButton12: TSpeedButton;
    SpeedButton13: TSpeedButton;
    SpeedButton14: TSpeedButton;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    buttonclear: TButton;
    Buttonstartposition: TButton;
    GroupBox2: TGroupBox;
    RadioButton1: TRadioButton;
    RadioButton2: TRadioButton;
    Button1: TButton;
    procedure FormPaint(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure buttonclearClick(Sender: TObject);
    procedure ButtonstartpositionClick(Sender: TObject);
    procedure SpeedButton7Click(Sender: TObject);
    procedure Image1MouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure Image1MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Image1MouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  change:boolean;
  formsetupboard1: Tformsetupboard1;
  newdata:tdata;
  piececursor:shortint;
  piece_rect2:trect;
  newpiece:boolean;
  gx,s_x:tbitmap;
implementation

uses Unit1,customboard,hashing_header;
{$R *.DFM}

Procedure gambar_piece_moving(x,y:integer;piece:shortint;fb:timage);
//untuk menggambar biji yang sedang digerakkan pada posisi x dan y
//piece adalah biji catur yang sedang digerakkan
// biji sedang digerakkan adalah biji yang kita drag n drop
begin
	with fb.canvas do begin
		if piece=_pionputih then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_pion);
         copymode:=cmsrcpaint;
         draw(x,y,g_pion_putih);
   	end;
      if piece=_pionhitam then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_pion);
         copymode:=cmsrcpaint;
         draw(x,y,g_pion_hitam);
   	end;
      if piece=_bentengputih then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_benteng);
         copymode:=cmsrcpaint;
         draw(x,y,g_benteng_putih);
   	end;
      if piece=_bentenghitam then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_benteng);
         copymode:=cmsrcpaint;
         draw(x,y,g_benteng_hitam);
   	end;
      if piece=_kudahitam then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_kuda);
         copymode:=cmsrcpaint;
         draw(x,y,g_kuda_hitam);
   	end;
      if piece=_kudaputih then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_kuda);
         copymode:=cmsrcpaint;
         draw(x,y,g_kuda_putih);
   	end;
      if piece=_gajahhitam then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_gajah);
         copymode:=cmsrcpaint;
         draw(x,y,g_gajah_hitam);
   	end;
      if piece=_gajahputih then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_gajah);
         copymode:=cmsrcpaint;
         draw(x,y,g_gajah_putih);
   	end;
      if piece=_mentriputih then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_mentri);
         copymode:=cmsrcpaint;
         draw(x,y,g_mentri_putih);
   	end;
      if piece=_mentrihitam then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_mentri);
         copymode:=cmsrcpaint;
         draw(x,y,g_mentri_hitam);
   	end;
      if piece=_rajahitam then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_raja);
         copymode:=cmsrcpaint;
         draw(x,y,g_raja_hitam);
   	end;
      if piece=_rajaputih then begin
         copymode:=cmsrcand;
         draw(x,y,g_latar_raja);
         copymode:=cmsrcpaint;
         draw(x,y,g_raja_putih);
   	end;
      if piece=remove then begin
	      copymode:=cmsrcand;
         draw(x,y,s_x);
         copymode:=cmsrcpaint;
         draw(x,y,gx);
      end;
   end;
end;

procedure gambar(var data:tdata;nodraw:byte;fb:tformsetupboard1);
//untuk menggambar papan di layar
var a,b:byte;
dest:trect;
//map:tarr;
begin
//  formsetupboard.image1.canvas.lock;

//  freeimage;
//  initimage;
  with fb.image1 do begin
	for a:=0 to 7 do
   for b:=0 to 7 do begin
    canvas.copymode:=cmsrccopy;
    dest:=rect(b*_size+_poskiri,a*_size+_posatas,b*_size+_poskiri+_size,a*_size+_posatas+_size);
    canvas.copyrect(dest,form1.imageself.canvas,dest);
    if map(7-a,b)<>nodraw then begin
      if data.papan[map(7-a,b)]=_pionputih then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_pion);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_pion_putih);
      end else
      if data.papan[map(7-a,b)]=_pionhitam then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri,a*_size+_posatas+1,g_latar_pion);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri,a*_size+_posatas+1,g_pion_hitam);
      end else
      if data.papan[map(7-a,b)]=_bentengputih then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri,a*_size+_posatas,g_latar_benteng);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri,a*_size+_posatas,g_benteng_putih);
      end
      else
      if data.papan[map(7-a,b)]=_bentenghitam then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri,a*_size+_posatas+1,g_latar_benteng);
	      canvas.copymode:=cmsrcpaint;
{         jumn:=0;
         inc(jumn,nodraw);}
      	canvas.draw(b*_size+_poskiri,a*_size+_posatas+1,g_benteng_hitam);
      end
      else
      if data.papan[map(7-a,b)]=_kudaputih then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_kuda);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_kuda_putih);
      end
      else
      if data.papan[map(7-a,b)]=_kudahitam then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_kuda);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_kuda_hitam);
      end
      else
      if data.papan[map(7-a,b)]=_gajahputih then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_gajah);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_gajah_putih);
      end
      else
      if data.papan[map(7-a,b)]=_gajahhitam then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_gajah);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_gajah_hitam);
      end
      else
      if data.papan[map(7-a,b)]=_mentriputih then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_mentri);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_mentri_putih);
      end
      else
      if data.papan[map(7-a,b)]=_mentrihitam then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_mentri);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_mentri_hitam);
      end
      else
      if data.papan[map(7-a,b)]=_rajaputih then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_raja);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_raja_putih);
      end
      else
      if data.papan[map(7-a,b)]=_rajahitam then begin
	      canvas.copymode:=cmsrcand;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_latar_raja);
	      canvas.copymode:=cmsrcpaint;
      	canvas.draw(b*_size+_poskiri+1,a*_size+_posatas+1,g_raja_hitam);
      end
     end;
   end;
   end;
end;

procedure gambarboard(fb:tformsetupboard1);
var dest:trect;
begin
	with fb do begin
		image1.canvas.copymode:=cmsrccopy;
      dest:=rect(0,0,image1.width,image1.height);
      image1.canvas.copyrect(dest,form1.imageself.canvas,dest);
   end;

end;


procedure Tformsetupboard1.FormPaint(Sender: TObject);
begin
 gambarboard(self);
// newdata:=data;
 piece_rect2:=rect(0,0,image1.width,image1.height);
 gambar(newdata,200,self);
 image2.canvas.copyrect(piece_rect2,image1.canvas,piece_rect2);
end;

procedure Tformsetupboard1.FormCreate(Sender: TObject);
begin
 newdata:=data;
 newdata.flagrokade:=0;
 piececursor:=hand;
 newpiece:=false;
 gx:=tbitmap.create;
 gx.loadfromfile(form1.defaultdir+'\images\x.bmp');
 s_x:=tbitmap.create;
 s_x.loadfromfile(form1.defaultdir+'\images\s_x.bmp');
 change:=false;
end;

procedure Tformsetupboard1.buttonclearClick(Sender: TObject);
var a:integer;
begin
// initstate(newdata);
 for a:=0 to 63 do
    newdata.papan[a]:=0;
 gambar(newdata,200,self);
end;

procedure Tformsetupboard1.ButtonstartpositionClick(Sender: TObject);
begin
 initstate(newdata);
 gambar(newdata,200,self);
end;

procedure Tformsetupboard1.SpeedButton7Click(Sender: TObject);
begin
  piececursor:=(sender as tspeedbutton).tag;
  if (piececursor<>hand) and (piececursor<>remove) then
	  newpiece:=true else newpiece:=false;
end;

procedure drawpiece(x,y:integer);
var source:trect;
begin
	   source:=piece_rect2;
      formsetupboard1.image1.canvas.copymode:=cmsrccopy;
  		formsetupboard1.image1.canvas.copyrect(piece_rect2,formsetupboard1.image2.canvas,source);//mengcopy kotak image.canvas
      formsetupboard1.image1.canvas.copymode:=cmsrccopy;
  //    formsetupboard1.image2.canvas.copymode:=cmsrccopy;
      piece_rect2:=rect(x-30,y-30,x+30,y+30);
      source:=piece_rect2;
      formsetupboard1.image2.canvas.copyrect(source,formsetupboard1.image1.canvas,piece_rect2);//mengcopy kotak di sekitar posisi mouse ke image.canvas
      gambar_piece_moving(x-30,y-30,piececursor,formsetupboard1.image1);
end;

procedure Tformsetupboard1.Image1MouseMove(Sender: TObject;
  Shift: TShiftState; X, Y: Integer);

begin
		   drawpiece(x,y);

//         formsetupboard1.image1.repaint;
end;

procedure Tformsetupboard1.Image1MouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var x1,y1:integer;
source:trect;
begin
 x1:=(x-_poskiri) div _size;
 y1:=(y-_posatas) div _size;
 y1:=7-y1;
 if (x1 in [0..7]) and (y1 in[0..7]) and (button=mbleft) then begin
{ label1.caption:=inttostr(y1);
 label2.caption:=inttostr(x1);}
 if newpiece then begin
    newdata.papan[map(y1,x1)]:=piececursor;
    change:=true;
    gambar(newdata,201,self);
    piece_rect2:=rect((x1*_size)+_poskiri,y1*_size+_posatas,x1*_size+_poskiri+60,y1*_size+_poskiri+60);
    source:=piece_rect2;
    formsetupboard1.image2.canvas.copyrect(source,formsetupboard1.image1.canvas,piece_rect2);//mengcopy kotak di sekitar posisi mouse ke image.canvas
 end else begin
    gambar(newdata,map(y1,x1),self);
    if piececursor<>remove then
    piececursor:=newdata.papan[map(y1,x1)];
    newdata.papan[map(y1,x1)]:=0;
    change:=true;
    piece_rect2:=rect(x-30,y-30,x+30,y+30);
    source:=piece_rect2;
    formsetupboard1.image2.canvas.copyrect(source,formsetupboard1.image1.canvas,piece_rect2);//mengcopy kotak di sekitar posisi mouse ke image.canvas
    gambar_piece_moving(x-30,y-30,piececursor,formsetupboard1.image1);
 end;
 end;
end;

procedure Tformsetupboard1.Image1MouseUp(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var x1,y1:integer;
source:trect;
begin
    x1:=(x-_poskiri) div _size;
	 y1:=(y-_posatas) div _size;
 	 y1:=7-y1;
if (x1 in [0..7]) and (y1 in[0..7]) and (button=mbleft) then begin
  if not newpiece and (piececursor<>remove) then begin
  	 change:=true;
    newdata.papan[map(y1,x1)]:=piececursor;
    gambar(newdata,201,self);
    piece_rect2:=rect((x1*_size)+_poskiri,y1*_size+_posatas,x1*_size+_poskiri+60,y1*_size+_poskiri+60);
    source:=piece_rect2;
    formsetupboard1.image2.canvas.copyrect(source,formsetupboard1.image1.canvas,piece_rect2);//mengcopy kotak di sekitar posisi mouse ke image.canvas
    piececursor:=hand;
  end;
end;
end;


function validasi(var data:tdata):boolean;
begin
  validasi:=true;
end;


procedure Tformsetupboard1.BitBtn1Click(Sender: TObject);
begin
 if validasi(newdata) then begin
	data:=newdata;
//  initrepdata;
   if radiobutton1.checked then form1.giliran:=_sisiputih else
   form1.giliran:=_sisihitam;
   fillbitboard(data);
   data.hashkey:=hashvalue(data,form1.giliran);
	modalresult:=mrok;
 end;
end;


procedure Tformsetupboard1.BitBtn2Click(Sender: TObject);
begin
if not change or (messagedlg('Are you sure you want to quit and discard any changes made?',mtinformation,[mbok,mbcancel],0)=mrok) then
	modalresult:=mrcancel;
end;

procedure Tformsetupboard1.FormShow(Sender: TObject);
begin
{  newdata:=data;
  gambar(data,200,self);    }
end;

procedure Tformsetupboard1.Button1Click(Sender: TObject);
var wtm:boolean;
s:string;
begin
   s:=inputbox('Input notation','Masukkan notasi : ','');
   if s<>'' then
   begin
     readnotation(s,newdata,wtm);
     if wtm then radiobutton1.checked:=true else radiobutton2.checked:=true;
     gambar(newdata,200,self);
   end;
end;

end.
