unit Unit6;

interface


uses
  Windows, Messages, SysUtils,  Classes, Graphics, Controls, Forms,
  Dialogs,header, StdCtrls;

type
  TFormInfo = class(TForm)
    Memo1: TMemo;
    procedure FormShow(Sender: TObject);
  private
    { Private declarations }
  public
      procedure writeinfo;
    { Public declarations }
  end;

var
  FormInfo: TFormInfo;

implementation
uses unit1,hashing_header;

procedure tforminfo.writeinfo;
var n:integer;
begin
  n:=22;
  memo1.Lines.clear;
  if players=_TWOPLAYERS then begin
    memo1.Lines.add(fstring('White ',n)+': Player');
    memo1.Lines.add(fstring('Black ',n)+': Player');
  end;
  if players=_PLAYERVSCOMP then begin
    memo1.Lines.add(fstring('White ',n)+': Player');
    memo1.Lines.add(fstring('Black ',n)+': Computer');
  end;
  if players=_COMPVSPLAYER then begin
    memo1.Lines.add(fstring('White ',n)+': Computer');
    memo1.Lines.add(fstring('Black ',n)+': Player');
  end;
  if use_mtdf then memo1.Lines.add(fstring('Search Algorithm',n)+': MTD(f)') else
     memo1.Lines.add(fstring('Search Algorithm',n)+': Negascout / PVS');
  case maxhash of
    262144*4 : memo1.Lines.add(fstring('Hash Table size',n)+': 32 MB');
    262144*2 : memo1.Lines.add(fstring('Hash Table size',n)+': 16 MB');
    262144*1 : memo1.Lines.add(fstring('Hash Table size',n)+': 8 MB');
    262144*8 : memo1.Lines.add(fstring('Hash Table size',n)+': 64 MB');
    262144*16 : memo1.Lines.add(fstring('Hash Table size',n)+': 128 MB');
    262144*32 : memo1.Lines.add(fstring('Hash Table size',n)+': 256 MB');
  end;
  if lazyOK then
  begin
    memo1.Lines.add(fstring('Lazy Eval',n)+': ON / '+inttostr(lazy_margin1));
  end else
  begin
     memo1.Lines.add(fstring('Lazy Eval',n)+': OFF');
  end;
  if futpruningOK then
  begin
    memo1.Lines.add(fstring('Futility Pruning',n)+': ON / '+inttostr(futil_margin));
//    memo1.Lines.add(fstring('   Margin',n)+':  '+inttostr(futil_margin))
  end else
  begin
     memo1.Lines.add(fstring('Futility Pruning',n)+': OFF');
  end;
  if QpruningOK then
  begin
    memo1.Lines.add(fstring('Quiescene Pruning',n)+': ON / '+inttostr(q_margin));
  end else
  begin
     memo1.Lines.add(fstring('Quiescene Pruning',n)+': OFF');
  end;
  if nullOK then memo1.Lines.add(fstring('Null Move Pruning',n)+': ON') else
    memo1.Lines.add(fstring('Null Move Pruning',n)+': OFF');


end;



{$R *.dfm}

procedure TFormInfo.FormShow(Sender: TObject);
begin
  writeinfo;
end;

end.
