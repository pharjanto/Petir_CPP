unit Unit11;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Spin;

type
  TForm11 = class(TForm)
    Label1: TLabel;
    ComboBox1: TComboBox;
    GroupBox1: TGroupBox;
    RadioButton1: TRadioButton;
    Label2: TLabel;
    RadioButton2: TRadioButton;
    SpinEdit1: TSpinEdit;
    SpinEdit2: TSpinEdit;
    Label3: TLabel;
    Button1: TButton;
    Button2: TButton;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
  public
    testfile:string;
    testtype,testlength:integer;
    { Public declarations }
  end;

var
  Form11: TForm11;

implementation
  uses header;

{$R *.dfm}

procedure TForm11.Button1Click(Sender: TObject);
begin
{  if combobox1.ItemIndex=0 then
    testfile:='\epd\ECM.epd'
  else
  if combobox1.ItemIndex=1 then
    testfile:='\epd\wac.epd' else
  if combobox1.itemindex=2 then
  testfile:='\epd\zug.epd'
  else
  if combobox1.itemindex=3 then
  testfile:='\epd\iq.epd' else
  if combobox1.itemindex=4 then
  testfile:='\epd\ECMGCP.epd' else
  if combobox1.itemindex=5 then
  testfile:='\epd\pet.epd' else
  if combobox1.itemindex=6 then
  testfile:='\epd\WM-TEST.EPD';
}
  testfile:='\epd\'+combobox1.Text;
  if radiobutton1.Checked then
  begin
    testtype:=FIXED_DEPTH;
    testlength:=spinedit1.Value;
  end else
  begin
    testtype:=SECONDS_MOVE;
    testlength:=spinedit2.Value*timefactor;

  end;
end;

procedure TForm11.FormCreate(Sender: TObject);
var sr:TSearchRec;
begin
  combobox1.items.clear;
  if findfirst('D:\Data\Chess\Petir\skakmaster2\epd\*.epd',faanyfile,sr)=0 then
  begin
    combobox1.items.add(sr.name);
    while findnext(sr)=0 do
    begin
      combobox1.items.add(sr.name);
    end;
  end;
end;

end.
