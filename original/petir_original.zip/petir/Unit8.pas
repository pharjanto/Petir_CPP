unit Unit8;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TFormClock = class(TForm)
    Edit1: TEdit;
    Edit2: TEdit;
    procedure FormShow(Sender: TObject);
  private
    { Private declarations }
  public
    procedure showclock;
    { Public declarations }
  end;

var
  FormClock: TFormClock;

implementation
uses header;

function strtime(time:longint):string;
var st1,st2,st3:string;
begin
 st1:=inttostr(time div 3600);
 if strtoint(st1)<10 then st1:='0'+st1;
 st2:=inttostr((time mod 3600 )div 60);
 if strtoint(st2)<10 then st2:='0'+st2;
 st3:=inttostr(time mod 60);
 if strtoint(st3)<10 then st3:='0'+st3;
 result:=st1+':'+st2+':'+st3;
end;


procedure tformclock.showclock;
begin
  edit1.text:=strtime(clockwhite div timefactor);
  edit2.text:=strtime(clockblack div timefactor);
end;

{$R *.dfm}

procedure TFormClock.FormShow(Sender: TObject);
begin
 showclock;
end;

end.
