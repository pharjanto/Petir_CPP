object Form11: TForm11
  Left = 253
  Top = 124
  Width = 263
  Height = 295
  Caption = 'Test Suites'
  Color = clSilver
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 21
    Top = 18
    Width = 59
    Height = 13
    Caption = 'Test Suites :'
  end
  object ComboBox1: TComboBox
    Left = 89
    Top = 16
    Width = 145
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 0
  end
  object GroupBox1: TGroupBox
    Left = 21
    Top = 58
    Width = 209
    Height = 137
    Caption = 'Test Length'
    TabOrder = 1
    object Label2: TLabel
      Left = 83
      Top = 48
      Width = 61
      Height = 13
      Caption = 'ply / problem'
    end
    object Label3: TLabel
      Left = 83
      Top = 104
      Width = 88
      Height = 13
      Caption = 'seconds / problem'
    end
    object RadioButton1: TRadioButton
      Left = 8
      Top = 24
      Width = 113
      Height = 17
      Caption = 'Fixed Depth'
      Checked = True
      TabOrder = 0
      TabStop = True
    end
    object RadioButton2: TRadioButton
      Left = 8
      Top = 80
      Width = 73
      Height = 17
      Caption = 'Use Timer'
      TabOrder = 1
    end
    object SpinEdit1: TSpinEdit
      Left = 27
      Top = 45
      Width = 46
      Height = 22
      MaxValue = 0
      MinValue = 0
      TabOrder = 2
      Value = 8
    end
    object SpinEdit2: TSpinEdit
      Left = 27
      Top = 101
      Width = 46
      Height = 22
      MaxValue = 0
      MinValue = 0
      TabOrder = 3
      Value = 10
    end
  end
  object Button1: TButton
    Left = 38
    Top = 216
    Width = 75
    Height = 25
    Caption = 'OK'
    Default = True
    ModalResult = 1
    TabOrder = 2
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 142
    Top = 216
    Width = 75
    Height = 25
    Cancel = True
    Caption = 'Cancel'
    ModalResult = 2
    TabOrder = 3
  end
end
