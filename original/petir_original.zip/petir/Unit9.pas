unit Unit9;

interface
uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, Grids,header;

type
  TForm9 = class(TForm)
    Edit1: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    StringGrid1: TStringGrid;
    Button1: TButton;
    Button2: TButton;
    procedure FormCreate(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure StringGrid1Click(Sender: TObject);
    procedure StringGrid1DblClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Edit1Change(Sender: TObject);
  private
    m:tmovelist;
    j:integer;
    procedure printmove(s:string);
    { Private declarations }
  public
    output:string;
    { Public declarations }
  end;

var
  Form9: TForm9;

implementation
uses movgen, Unit1,tools,notation;

{$R *.dfm}
procedure tform9.printmove;
var a:integer;
var x,y:integer;
var st:string;
begin

  for x:=0 to stringgrid1.colCount-1 do
  for y:=0 to stringgrid1.rowcount-1 do
    stringgrid1.Cells[x,y]:='';
  x:=0;y:=0;
  for a:=1 to j do
  begin
    st:=copy(movetonotation(m[a].moves,data.ep,form1.giliran),1,length(s));
    if (s='') or (st=s) then
    begin
      stringgrid1.Cells[x,y]:=movetonotation(m[a].moves,data.ep,form1.giliran);
      inc(y);
      if y>stringgrid1.RowCount-1 then
      begin
        y:=0;inc(x);
      end;
    end;
  end;

end;

procedure TForm9.FormCreate(Sender: TObject);
var ml:tmovelist;a,jml,x,y,sc:integer;
var g:tgridrect;
begin
  x:=0;y:=0;
  if form1.giliran=_SISIPUTIH then
  begin
    if white_checked(data) then
    begin
      white_evasion(data,ml,jml,sc);
      m:=ml;j:=jml;
    end else
    begin
      white_movgen_caps(data,ml,jml);
      m:=ml;j:=jml;
      white_movgen_noncaps(data,ml,jml,0);
      for a:=1 to jml do
      begin
        inc(j);m[j]:=ml[a];
      end;
    end;
  end else
  begin
    if black_checked(data) then
    begin
      black_evasion(data,ml,jml,sc);
      m:=ml;j:=jml;
    end else
    begin
      black_movgen_caps(data,ml,jml);
      m:=ml;j:=jml;
      black_movgen_noncaps(data,ml,jml);
      for a:=1 to jml do
      begin
        inc(j);m[j]:=ml[a];
      end;

    end;
  end;
  printmove('');
  edit1.text:=stringgrid1.Cells[0,0];
  edit1.OnChange:=edit1change;
  g.Left:=0;g.Top:=0;
  g.Right:=0;g.Bottom:=0;
  stringgrid1.Selection:=g;

end;

procedure TForm9.Button1Click(Sender: TObject);
begin
//  output:=edit1.text;
end;

procedure TForm9.StringGrid1Click(Sender: TObject);
var g:tgridrect;
begin
  g:=stringgrid1.Selection;
  edit1.OnChange:=nil;
  edit1.text:=stringgrid1.Cells[g.left,g.top];
  edit1.OnChange:=edit1change;
end;

procedure TForm9.StringGrid1DblClick(Sender: TObject);
var g:tgridrect;
action:tcloseaction;
begin
  g:=stringgrid1.Selection;
  edit1.Text:=stringgrid1.Cells[g.left,g.top];
  modalresult:=mrok;
  formclose(sender,action);
end;

procedure TForm9.FormClose(Sender: TObject; var Action: TCloseAction);
var g:tgridrect;
begin
  g:=stringgrid1.Selection;
  edit1.Text:=stringgrid1.Cells[g.left,g.top];
  output:=edit1.text;
end;

procedure TForm9.Edit1Change(Sender: TObject);
begin
  printmove(edit1.Text);
end;

end.
